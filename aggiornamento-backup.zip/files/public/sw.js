/* L'app va aperta una prima volta online, anche dopo l'aggiunta alla Home. */
const CACHE_NAME = "schede-clienti-shell-v8";

self.addEventListener("install", (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    const response = await fetch(new Request("/", { cache: "reload" }));
    if (!response.ok) throw new Error("Impossibile preparare l'app offline");

    // Salva la pagina e tutte le risorse di Next.js necessarie ad avviarla.
    const html = await response.clone().text();
    await cache.put("/", response);
    const urls = new Set(["/manifest.json", "/icon-192.png", "/icon-512.png"]);
    const pattern = /\/_next\/static\/[^"'<>\\\s]+?\.(?:js|css)(?:\?[^"'<>\\\s]*)?/g;
    for (const match of html.matchAll(pattern)) urls.add(match[0]);
    if (urls.size <= 3) throw new Error("Risorse dell'app non trovate");
    await Promise.all([...urls].map((url) => cache.add(url)));
    await self.skipWaiting();
  })());
});

self.addEventListener("activate", (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter((key) => key.startsWith("schede-clienti-shell-") && key !== CACHE_NAME)
      .map((key) => caches.delete(key)));
    await self.clients.claim();
  })());
});

self.addEventListener("fetch", (event) => {
  const request = event.request;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin || request.method !== "GET") return;

  // Mai conservare in cache le API: i dati sensibili vivono nel database locale.
  if (url.pathname.startsWith("/api/")) return;

  if (request.mode === "navigate") {
    event.respondWith((async () => {
      const cache = await caches.open(CACHE_NAME);
      try {
        const response = await fetch(request);
        if (response.ok) await cache.put(url.pathname === "/" ? "/" : request, response.clone());
        return response;
      } catch {
        return (await cache.match(request)) || (await cache.match("/")) || Response.error();
      }
    })());
    return;
  }

  if (url.pathname.startsWith("/_next/static/") ||
      ["/manifest.json", "/icon-192.png", "/icon-512.png"].includes(url.pathname)) {
    event.respondWith((async () => {
      const cache = await caches.open(CACHE_NAME);
      const cached = await cache.match(request);
      if (cached) return cached;
      try {
        const response = await fetch(request);
        if (response.ok) await cache.put(request, response.clone());
        return response;
      } catch {
        return Response.error();
      }
    })());
  }
});

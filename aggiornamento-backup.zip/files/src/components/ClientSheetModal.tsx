"use client";

import React, { useState } from "react";
import { CalendarDays, CalendarPlus, Clock3, Euro, FileText, History, MapPin, Phone, Plus, Save, ShieldCheck, ShieldOff, Tags, Trash2, UserRound, X } from "lucide-react";
import type { ClientData, PriceHistoryItem, Recurrence, ServiceData, WeeklyIntervention } from "@/types/client";
import { RECURRENCE_LABELS, WEEK_DAYS } from "@/types/client";
import {
  formatDayMonth, formatMoney, getInterventions, interventionKey, interventionLabel, localDate,
  monthlyAmount, monthlyEstimate, recurrenceOf, round2, scheduleLabel, timeToMinutes, weekdayName, weeklyEquivalent,
} from "@/lib/client-utils";

type Tab = "dati" | "prezzi" | "interventi" | "note";

interface Row {
  key: string;
  day: string;
  time: string;
  price: string;
  duration: string;
  recurrence: Recurrence;
  anchorDate: string;
  spotDate: string;
}

const inputClass = "w-full min-w-0 rounded-xl border border-emerald-600/50 bg-emerald-950/80 px-3.5 py-3 text-base text-white placeholder-emerald-600 outline-none focus:border-emerald-400 focus:ring-2 focus:ring-emerald-500/30";
const labelClass = "mb-1.5 block text-xs font-bold uppercase tracking-wider text-emerald-200";
const panelClass = "rounded-2xl border border-emerald-700/40 bg-emerald-900/35 p-4 sm:p-5";
const decimal = (text: string) => Number(text.trim().replace(",", "."));
const newKey = () => typeof crypto.randomUUID === "function" ? crypto.randomUUID() : `row-${Date.now()}-${Math.random().toString(36).slice(2)}`;

function rowsFromClient(client: ClientData): Row[] {
  return getInterventions(client).map((item) => {
    const recurrence = recurrenceOf(item);
    return {
      key: recurrence === "spot" ? `spot-${item.spotDate ?? newKey()}` : item.day,
      day: item.day,
      time: item.time || "",
      price: item.price == null ? "" : String(item.price),
      duration: item.durationHours == null ? "" : String(item.durationHours),
      recurrence,
      anchorDate: item.anchorDate || (recurrence === "biweekly" ? localDate() : ""),
      spotDate: item.spotDate || (recurrence === "spot" ? localDate() : ""),
    };
  }).sort((a, b) => (WEEK_DAYS.indexOf(a.day as typeof WEEK_DAYS[number]) - WEEK_DAYS.indexOf(b.day as typeof WEEK_DAYS[number])) || timeToMinutes(a.time) - timeToMinutes(b.time));
}

const historyId = () => typeof crypto.randomUUID === "function" ? crypto.randomUUID() : `ph-${Date.now()}-${Math.random().toString(36).slice(2)}`;

interface Props {
  client: ClientData | null;
  isOpen: boolean;
  isNew?: boolean;
  services: ServiceData[];
  onManageServices: () => void;
  onClose: () => void;
  onSave: (updatedClient: ClientData) => Promise<boolean>;
  onDelete: (uuid: string) => Promise<boolean>;
}

function Sheet({ client, isNew, services, onManageServices, onClose, onSave, onDelete }: Omit<Props, "isOpen" | "client"> & { client: ClientData }) {
  const [form, setForm] = useState<ClientData>({ ...client });
  const [basePrice, setBasePrice] = useState(String(client.currentPrice ?? 0));
  const [monthlyPrice, setMonthlyPrice] = useState(client.monthlyPriceOverride == null ? "" : String(client.monthlyPriceOverride));
  const [rows, setRows] = useState<Row[]>(() => rowsFromClient(client));
  const [tab, setTab] = useState<Tab>("dati");
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);

  const setField = <K extends keyof ClientData>(key: K, value: ClientData[K]) => setForm((previous) => ({ ...previous, [key]: value }));

  function toggleRecurringDay(day: string) {
    setRows((previous) => {
      const existing = previous.find((row) => row.recurrence !== "spot" && row.day === day);
      if (existing) return previous.filter((row) => row.key !== existing.key);
      return [...previous, { key: day, day, time: "", price: "", duration: "", recurrence: "weekly", anchorDate: "", spotDate: "" }];
    });
  }

  function addSpot() {
    const today = localDate();
    setRows((previous) => [...previous, { key: `spot-${newKey()}`, day: weekdayName(today), time: "", price: "", duration: "", recurrence: "spot", anchorDate: "", spotDate: today }]);
  }

  function updateRow(key: string, patch: Partial<Row>) {
    setRows((previous) => previous.map((row) => row.key === key ? { ...row, ...patch } : row));
  }

  function changeRecurrence(key: string, recurrence: Recurrence) {
    setRows((previous) => previous.map((row) => {
      if (row.key !== key) return row;
      if (recurrence === "spot") {
        const date = row.spotDate || localDate();
        return { ...row, recurrence, spotDate: date, day: weekdayName(date), anchorDate: "", key: `spot-${newKey()}` };
      }
      const anchor = recurrence === "biweekly" ? (row.anchorDate || localDate()) : "";
      return { ...row, recurrence, anchorDate: anchor, spotDate: "", key: row.day };
    }));
  }

  const baseNum = basePrice.trim() && Number.isFinite(decimal(basePrice)) ? decimal(basePrice) : 0;
  const previewInterventions: WeeklyIntervention[] = rows.map((row) => ({
    day: row.recurrence === "spot" ? weekdayName(row.spotDate) : row.day,
    time: row.time,
    price: row.price.trim() && Number.isFinite(decimal(row.price)) ? decimal(row.price) : null,
    durationHours: row.duration.trim() && Number.isFinite(decimal(row.duration)) ? decimal(row.duration) : null,
    recurrence: row.recurrence,
    anchorDate: row.recurrence === "biweekly" ? (row.anchorDate || localDate()) : null,
    spotDate: row.recurrence === "spot" ? (row.spotDate || localDate()) : null,
  }));
  const preview: ClientData = {
    ...form, currentPrice: baseNum, interventions: previewInterventions,
    monthlyPriceOverride: monthlyPrice.trim() && Number.isFinite(decimal(monthlyPrice)) ? decimal(monthlyPrice) : null,
  };

  async function save() {
    if (!form.name.trim()) { setTab("dati"); return setError("Inserisci il nome del cliente."); }
    if (!form.activationDate) { setTab("dati"); return setError("Inserisci la data di attivazione."); }
    const price = decimal(basePrice);
    if (!basePrice.trim() || !Number.isFinite(price) || price < 0 || price > 99999999.99) { setTab("prezzi"); return setError("Inserisci un prezzo base valido."); }
    const monthly = monthlyPrice.trim() ? decimal(monthlyPrice) : null;
    if (monthly !== null && (!Number.isFinite(monthly) || monthly < 0 || monthly > 99999999.99)) { setTab("prezzi"); return setError("Inserisci un prezzo mensile valido oppure lascia vuoto per la stima."); }
    for (const row of rows) {
      if (row.price.trim() && (!Number.isFinite(decimal(row.price)) || decimal(row.price) < 0 || decimal(row.price) > 99999999.99)) { setTab("interventi"); return setError(`Controlla il prezzo di ${row.day}.`); }
      if (row.duration.trim() && (!Number.isFinite(decimal(row.duration)) || decimal(row.duration) < 0.01 || decimal(row.duration) > 24)) { setTab("interventi"); return setError(`La durata di ${row.day} deve essere tra 0,01 e 24 ore.`); }
      if (row.recurrence === "spot" && !row.spotDate) { setTab("interventi"); return setError("Scegli la data dell’intervento a spot."); }
      if (row.recurrence === "biweekly" && !row.anchorDate) { setTab("interventi"); return setError(`Indica una data di riferimento per l’intervento quindicinale di ${row.day}.`); }
    }
    const recurringDays = rows.filter((row) => row.recurrence !== "spot").map((row) => row.day);
    if (new Set(recurringDays).size !== recurringDays.length) { setTab("interventi"); return setError("Ogni giorno può avere un solo intervento settimanale o quindicinale."); }
    const spotDates = rows.filter((row) => row.recurrence === "spot").map((row) => row.spotDate);
    if (new Set(spotDates).size !== spotDates.length) { setTab("interventi"); return setError("Due interventi a spot hanno la stessa data: scegli date diverse."); }

    const interventions: WeeklyIntervention[] = previewInterventions.map((item) => ({
      ...item, price: item.price == null ? null : round2(item.price), durationHours: item.durationHours == null ? null : round2(item.durationHours),
    })).sort((a, b) => WEEK_DAYS.indexOf(a.day as typeof WEEK_DAYS[number]) - WEEK_DAYS.indexOf(b.day as typeof WEEK_DAYS[number]) || timeToMinutes(a.time) - timeToMinutes(b.time));
    const firstRecurring = interventions.find((item) => recurrenceOf(item) !== "spot");
    const updated: ClientData = {
      ...form, name: form.name.trim(), vatNumber: (form.vatNumber || "").trim(), currentPrice: round2(price),
      monthlyPriceOverride: monthly === null ? null : round2(monthly), interventions,
      interventionDay: firstRecurring?.day || "Da concordare", interventionTime: firstRecurring?.time || "",
    };

    const history: PriceHistoryItem[] = [];
    const addHistory = (oldPrice: number, newPrice: number, reason: string) => history.push({ id: historyId(), date: localDate(), oldPrice, newPrice, reason, createdAt: new Date().toISOString() });
    if (isNew) addHistory(updated.currentPrice, updated.currentPrice, "Prezzo base iniziale");
    else {
      if (Number(client.currentPrice) !== updated.currentPrice) addHistory(Number(client.currentPrice), updated.currentPrice, "Prezzo base modificato direttamente");
      const before = new Map(getInterventions(client).map((item) => [interventionKey(item), item]));
      for (const item of interventions) {
        const old = before.get(interventionKey(item));
        if (!old) continue;
        const oldAmount = Number(old.price ?? client.currentPrice), newAmount = Number(item.price ?? updated.currentPrice);
        if (oldAmount !== newAmount) addHistory(oldAmount, newAmount, `Prezzo intervento ${interventionLabel(item)}`);
      }
      if ((client.monthlyPriceOverride ?? null) !== updated.monthlyPriceOverride && monthlyAmount(client) !== monthlyAmount(updated)) {
        addHistory(monthlyAmount(client), monthlyAmount(updated), updated.monthlyPriceOverride == null ? "Ripristinata stima mensile" : "Prezzo mensile concordato");
      }
    }
    updated.priceHistory = [...history, ...(client.priceHistory || [])];

    setSaving(true); setError("");
    const ok = await onSave(updated);
    setSaving(false);
    if (ok) onClose(); else setError("Impossibile salvare. Controlla la memoria dell’iPad e riprova.");
  }

  const tabs: { id: Tab; label: string; icon: typeof UserRound }[] = [
    { id: "dati", label: "Dati cliente", icon: UserRound },
    { id: "prezzi", label: "Prezzi e mensile", icon: Euro },
    { id: "interventi", label: "Interventi", icon: CalendarDays },
    { id: "note", label: "Note", icon: FileText },
  ];

  return <div data-rolodex-modal="true" className="fixed inset-0 z-40 flex items-center justify-center bg-emerald-950/85 p-3 text-emerald-100 backdrop-blur-md sm:p-6">
    <div role="dialog" aria-modal="true" aria-labelledby="client-sheet-title" className="flex max-h-[94dvh] w-full max-w-4xl flex-col overflow-hidden rounded-3xl border border-emerald-500/40 bg-gradient-to-b from-[#093d2e] via-[#064e3b] to-[#043324] shadow-2xl">
      <div className="flex shrink-0 items-center justify-between border-b border-emerald-700/50 bg-emerald-900 px-5 py-4">
        <div><p className="text-[10px] font-bold uppercase tracking-[.18em] text-emerald-300">Schedario clienti</p><h2 id="client-sheet-title" className="mt-0.5 text-lg font-extrabold text-white">{isNew ? "Nuova scheda cliente" : form.name || "Scheda cliente"}</h2></div>
        <button type="button" aria-label="Chiudi scheda" onClick={onClose} className="rounded-full p-2 text-emerald-200 hover:bg-emerald-800"><X size={20} /></button>
      </div>
      <div className="flex shrink-0 flex-wrap items-center justify-between gap-3 border-b border-emerald-700/40 bg-emerald-950/40 px-5 py-3">
        <div className="flex flex-wrap items-center gap-2">
          <button type="button" onClick={() => setForm({ ...form, isActive: !form.isActive, deactivationDate: form.isActive ? form.deactivationDate || localDate() : null })} className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-bold ${form.isActive ? "bg-emerald-400 text-emerald-950" : "bg-red-900/80 text-red-200"}`}>{form.isActive ? <ShieldCheck size={14} /> : <ShieldOff size={14} />}{form.isActive ? "Attivo" : "Disattivato"}</button>
          <span className="rounded-full border border-emerald-700/60 px-3 py-1.5 text-xs text-emerald-200">{scheduleLabel(preview) || "Da concordare"}</span>
        </div>
        <div className="text-right"><span className="block text-[10px] font-bold uppercase tracking-wider text-emerald-300">{preview.monthlyPriceOverride == null ? "Stima mensile" : "Mensile concordato"}</span><strong className="text-xl text-white">{formatMoney(monthlyAmount(preview))}</strong></div>
      </div>
      <div className="flex shrink-0 gap-1 overflow-x-auto border-b border-emerald-700/40 bg-emerald-950/50 px-3">
        {tabs.map(({ id, label, icon: Icon }) => <button key={id} type="button" onClick={() => { setTab(id); setError(""); }} className={`flex shrink-0 items-center gap-2 border-b-2 px-3 py-3 text-xs font-bold sm:px-4 sm:text-sm ${tab === id ? "border-emerald-400 bg-emerald-900/40 text-white" : "border-transparent text-emerald-300/70 hover:text-white"}`}><Icon size={16} />{label}</button>)}
      </div>

      <div className="touch-scroll flex-1 space-y-4 overflow-y-auto p-4 sm:p-6">
        {tab === "dati" && <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div className="sm:col-span-2"><label className={labelClass} htmlFor="client-name">Nome cliente / ragione sociale *</label><input id="client-name" value={form.name} onChange={(e) => setField("name", e.target.value)} placeholder="Nome del cliente" className={inputClass} /></div>
          <div><label className={labelClass} htmlFor="client-vat">Partita IVA</label><input id="client-vat" value={form.vatNumber || ""} onChange={(e) => setField("vatNumber", e.target.value)} placeholder="Partita IVA" maxLength={50} className={inputClass} /></div>
          <div><label className={labelClass} htmlFor="client-service">Categoria servizio</label><div className="flex gap-2"><select id="client-service" value={form.category || ""} onChange={(e) => setField("category", e.target.value)} className={inputClass}><option value="">Seleziona servizio</option>{form.category && !services.some((service) => service.name === form.category) && <option value={form.category}>{form.category}</option>}{services.map((service) => <option key={service.uuid} value={service.name}>{service.name}</option>)}</select><button type="button" onClick={onManageServices} className="shrink-0 rounded-xl border border-emerald-500/40 bg-emerald-800 px-3 text-emerald-100" aria-label="Gestisci servizi" title="Aggiungi o rimuovi servizi"><Plus size={19} /></button></div></div>
          <div className="sm:col-span-2"><label className={labelClass} htmlFor="client-address">Indirizzo</label><div className="flex gap-2"><input id="client-address" value={form.address || ""} onChange={(e) => setField("address", e.target.value)} placeholder="Via, numero civico e città" className={inputClass} />{form.address && <a href={`https://maps.apple.com/?q=${encodeURIComponent(form.address)}`} target="_blank" rel="noreferrer" className="flex shrink-0 items-center gap-1 rounded-xl bg-emerald-800 px-3 text-xs font-semibold text-emerald-100"><MapPin size={15} /> Mappa</a>}</div></div>
          <div><label className={labelClass} htmlFor="client-phone">Telefono</label><input id="client-phone" type="tel" value={form.phone || ""} onChange={(e) => setField("phone", e.target.value)} placeholder="Numero di telefono" className={inputClass} /></div>
          <div><label className={labelClass} htmlFor="client-email">Email</label><input id="client-email" type="email" value={form.email || ""} onChange={(e) => setField("email", e.target.value)} placeholder="cliente@esempio.it" className={inputClass} /></div>
          <div><label className={labelClass} htmlFor="client-start">Data attivazione *</label><input id="client-start" type="date" value={form.activationDate} onChange={(e) => setField("activationDate", e.target.value)} className={inputClass} /></div>
          <div><label className={labelClass} htmlFor="client-end">Data disattivazione</label><input id="client-end" type="date" value={form.deactivationDate || ""} onChange={(e) => setField("deactivationDate", e.target.value || null)} className={inputClass} /></div>
          {form.phone && <a href={`tel:${form.phone}`} className="inline-flex w-fit items-center gap-2 rounded-lg bg-emerald-800/70 px-3 py-2 text-xs font-semibold text-emerald-100"><Phone size={14} /> Chiama cliente</a>}
        </div>}

        {tab === "prezzi" && <div className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className={panelClass}><label className={labelClass} htmlFor="base-price">Prezzo base per intervento (€)</label><input id="base-price" type="text" inputMode="decimal" value={basePrice} onChange={(e) => setBasePrice(e.target.value)} placeholder="Es. 120,00" className={`${inputClass} text-xl font-bold`} /><p className="mt-2 text-xs leading-5 text-emerald-300/80">Modificalo quando vuoi, anche con cliente attivo. È usato nei giorni senza prezzo specifico.</p></div>
            <div className={panelClass}><label className={labelClass} htmlFor="monthly-price">Prezzo mensile concordato (€)</label><input id="monthly-price" type="text" inputMode="decimal" value={monthlyPrice} onChange={(e) => setMonthlyPrice(e.target.value)} placeholder="Lascia vuoto per la stima" className={`${inputClass} text-xl font-bold`} /><p className="mt-2 text-xs leading-5 text-emerald-300/80">Facoltativo: lascia vuoto per calcolarlo dai giorni scelti.</p></div>
          </div>
          <div className="grid gap-3 rounded-2xl border border-emerald-500/30 bg-emerald-950/50 p-4 sm:grid-cols-3">
            <div><span className="text-xs text-emerald-300">Media settimanale</span><p className="mt-1 text-xl font-black text-white">{formatMoney(weeklyEquivalent(preview))}</p></div>
            <div><span className="text-xs text-emerald-300">Stima mensile</span><p className="mt-1 text-xl font-black text-white">{formatMoney(monthlyEstimate(preview))}</p></div>
            <div><span className="text-xs text-emerald-300">Prezzo mensile indicato</span><p className="mt-1 text-xl font-black text-emerald-300">{formatMoney(monthlyAmount(preview))}</p></div>
            <p className="text-xs leading-5 text-emerald-300/75 sm:col-span-3">Stima: media settimanale × 52 settimane ÷ 12 mesi. Il quindicinale conta metà; gli interventi a spot non entrano nella stima perché non sono ricorrenti.</p>
          </div>
          <div className={panelClass}><h3 className="mb-3 flex items-center gap-2 text-sm font-bold text-white"><History size={16} /> Storico variazioni</h3>{form.priceHistory?.length ? <div className="space-y-2">{form.priceHistory.map((item) => <div key={item.id} className="flex flex-wrap justify-between gap-2 rounded-xl border border-emerald-700/40 bg-emerald-950/50 px-3 py-3 text-sm"><span><strong className="text-white">{formatMoney(item.oldPrice)} → {formatMoney(item.newPrice)}</strong><span className="mt-1 block text-xs text-emerald-300">{item.reason}</span></span><span className="text-xs text-emerald-300">{item.date}</span></div>)}</div> : <p className="text-sm text-emerald-300/80">Le modifiche ai prezzi saranno registrate qui al salvataggio.</p>}</div>
        </div>}

        {tab === "interventi" && <div className="space-y-4">
          <div className={panelClass}>
            <h3 className="text-sm font-bold text-white">Giorni fissi dell’intervento</h3>
            <p className="mt-1 text-xs text-emerald-300/80">Scegli uno o più giorni. Dopo, per ciascuno, decidi se è settimanale o quindicinale.</p>
            <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
              {WEEK_DAYS.map((day) => {
                const selected = rows.some((row) => row.recurrence !== "spot" && row.day === day);
                return <button key={day} type="button" aria-pressed={selected} onClick={() => toggleRecurringDay(day)} className={`min-h-11 rounded-xl border px-2 py-2 text-sm font-bold ${selected ? "border-emerald-300 bg-emerald-400 text-emerald-950" : "border-emerald-700/50 bg-emerald-950/70 text-emerald-200"}`}>{day}</button>;
              })}
            </div>
            <button type="button" onClick={addSpot} className="mt-3 inline-flex min-h-11 items-center gap-2 rounded-xl border border-emerald-500/50 bg-emerald-800/70 px-3 py-2 text-sm font-bold text-emerald-50"><CalendarPlus size={16} /> Aggiungi intervento a spot</button>
          </div>

          {rows.length === 0 ? <div className="rounded-2xl border border-dashed border-emerald-700/60 p-6 text-center text-sm text-emerald-300">Nessun intervento pianificato. Il calendario rimane da concordare.</div> : rows.map((row) => {
            const spot = row.recurrence === "spot";
            return <div key={row.key} className={panelClass}>
              <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
                <h3 className="flex items-center gap-2 font-bold text-white"><CalendarDays size={17} className="text-emerald-400" /> {spot ? `Spot · ${weekdayName(row.spotDate)} ${formatDayMonth(row.spotDate)}` : row.day}</h3>
                <button type="button" onClick={() => setRows((previous) => previous.filter((item) => item.key !== row.key))} className="text-xs text-emerald-300 underline underline-offset-2">Rimuovi</button>
              </div>
              <div className="mb-3 grid grid-cols-1 gap-2 sm:grid-cols-3">
                {(["weekly", "biweekly", "spot"] as Recurrence[]).map((value) => <button key={value} type="button" aria-pressed={row.recurrence === value} onClick={() => changeRecurrence(row.key, value)} className={`min-h-10 rounded-lg border px-2 py-2 text-xs font-bold ${row.recurrence === value ? "border-emerald-300 bg-emerald-400 text-emerald-950" : "border-emerald-700/50 bg-emerald-950/60 text-emerald-200"}`}>{RECURRENCE_LABELS[value]}</button>)}
              </div>
              {row.recurrence === "biweekly" && <div className="mb-3 rounded-xl border border-emerald-600/30 bg-emerald-950/50 p-3">
                <label className={labelClass} htmlFor={`anchor-${row.key}`}>Settimana di riferimento</label>
                <input id={`anchor-${row.key}`} type="date" value={row.anchorDate} onChange={(e) => updateRow(row.key, { anchorDate: e.target.value })} className={inputClass} />
                <p className="mt-1.5 text-xs leading-5 text-emerald-300/80">Indica una data in cui l’intervento è previsto: l’agenda alterna una settimana sì e una no, a partire da quella data.</p>
              </div>}
              {spot && <div className="mb-3 rounded-xl border border-emerald-600/30 bg-emerald-950/50 p-3">
                <label className={labelClass} htmlFor={`spot-${row.key}`}>Data dell’intervento a spot</label>
                <input id={`spot-${row.key}`} type="date" value={row.spotDate} onChange={(e) => updateRow(row.key, { spotDate: e.target.value, day: weekdayName(e.target.value) })} className={inputClass} />
                <p className="mt-1.5 text-xs leading-5 text-emerald-300/80">Comparirà in agenda solo nella settimana di questa data.</p>
              </div>}
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
                <div><label className={labelClass} htmlFor={`time-${row.key}`}>Fascia oraria</label><input id={`time-${row.key}`} value={row.time} onChange={(e) => updateRow(row.key, { time: e.target.value })} placeholder="Es. 08:30 - 10:00" maxLength={100} className={inputClass} /><p className="mt-1 text-[11px] text-emerald-300/70">L’agenda ordina per questo orario.</p></div>
                <div><label className={labelClass} htmlFor={`duration-${row.key}`}>Durata (ore)</label><input id={`duration-${row.key}`} type="text" inputMode="decimal" value={row.duration} onChange={(e) => updateRow(row.key, { duration: e.target.value })} placeholder="Es. 1,5 o 3" className={inputClass} /></div>
                <div><label className={labelClass} htmlFor={`price-${row.key}`}>Prezzo del giorno (€)</label><input id={`price-${row.key}`} type="text" inputMode="decimal" value={row.price} onChange={(e) => updateRow(row.key, { price: e.target.value })} placeholder={`Base ${formatMoney(baseNum)}`} className={inputClass} /></div>
              </div>
              {row.recurrence === "biweekly" && <p className="mt-2 text-xs text-emerald-300/80"><Clock3 size={13} className="mr-1 inline" />Quindicinale: l’importo conta metà nella stima mensile.</p>}
              {spot && <p className="mt-2 text-xs text-emerald-300/80"><Clock3 size={13} className="mr-1 inline" />A spot: non entra nella stima mensile.</p>}
            </div>;
          })}
        </div>}

        {tab === "note" && <div className={panelClass}><label className={labelClass} htmlFor="client-notes">Note e istruzioni</label><textarea id="client-notes" rows={8} value={form.notes || ""} onChange={(e) => setField("notes", e.target.value)} placeholder="Scrivi le informazioni utili per il cliente..." className={`${inputClass} leading-relaxed`} /></div>}
      </div>

      {error && <div role="alert" className="shrink-0 bg-red-950 px-5 py-2 text-sm text-red-200">{error}</div>}
      <div className="flex shrink-0 flex-wrap items-center justify-between gap-3 border-t border-emerald-700/50 bg-emerald-950 px-4 py-4 sm:px-5">
        <div>{!isNew && (confirmDelete ? <div className="flex items-center gap-2 text-xs text-red-200"><span>Eliminare la scheda?</span><button type="button" disabled={saving} onClick={async () => { setSaving(true); const done = await onDelete(form.uuid); setSaving(false); if (done) onClose(); else setError("Impossibile eliminare la scheda."); }} className="rounded-lg bg-red-700 px-3 py-2 font-bold text-white">Sì, elimina</button><button type="button" onClick={() => setConfirmDelete(false)} className="px-2 py-2">Annulla</button></div> : <button type="button" onClick={() => setConfirmDelete(true)} className="inline-flex items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-semibold text-red-300 hover:bg-red-950"><Trash2 size={15} /> Elimina</button>)}</div>
        <div className="flex items-center gap-2">
          <button type="button" onClick={onManageServices} className="hidden rounded-xl border border-emerald-700/60 px-3 py-2.5 text-xs font-semibold text-emerald-200 sm:inline-flex sm:items-center sm:gap-1.5"><Tags size={15} /> Servizi</button>
          <button type="button" onClick={onClose} className="rounded-xl border border-emerald-700/60 px-4 py-2.5 text-sm text-emerald-200">Chiudi</button>
          <button type="button" onClick={() => void save()} disabled={saving} className="inline-flex items-center gap-2 rounded-xl bg-emerald-400 px-5 py-2.5 text-sm font-extrabold text-emerald-950 disabled:opacity-50"><Save size={16} /> {saving ? "Salvataggio…" : isNew ? "Crea scheda" : "Salva scheda"}</button>
        </div>
      </div>
    </div>
  </div>;
}

export function ClientSheetModal({ client, isOpen, isNew = false, ...rest }: Props) {
  if (!isOpen || !client) return null;
  return <Sheet key={`${client.uuid}-${isNew ? "new" : "edit"}`} client={client} isNew={isNew} {...rest} />;
}

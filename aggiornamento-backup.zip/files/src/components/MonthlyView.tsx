"use client";

import { CalendarDays, ChevronRight, CircleDollarSign, Info } from "lucide-react";
import type { ClientData } from "@/types/client";
import { formatMoney, getInterventions, monthlyAmount, recurrenceOf, scheduleLabel, weeklyEquivalent } from "@/lib/client-utils";

export function MonthlyView({ clients, onSelectClient }: { clients: ClientData[]; onSelectClient: (client: ClientData) => void }) {
  const active = clients.filter((client) => client.isActive);
  const total = active.reduce((sum, client) => sum + monthlyAmount(client), 0);
  const spotOnly = active.filter((client) => {
    const items = getInterventions(client);
    return items.length > 0 && items.every((item) => recurrenceOf(item) === "spot");
  }).length;

  return <div className="touch-scroll flex flex-1 flex-col overflow-y-auto p-4 sm:p-6">
    <div className="mx-auto w-full max-w-5xl space-y-5 pb-10">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <p className="text-xs font-bold uppercase tracking-[.18em] text-emerald-400">Riepilogo clienti</p>
          <h2 className="mt-1 text-xl font-extrabold text-white sm:text-2xl">Prezzi mensili</h2>
          <p className="mt-1 text-sm text-emerald-300/80">Prezzi concordati o stime per ogni cliente.</p>
        </div>
        <div className="rounded-2xl border border-emerald-600/40 bg-emerald-950/70 px-5 py-3">
          <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-300">Totale mensile · clienti attivi</span>
          <p className="text-2xl font-black text-white">{formatMoney(total)}</p>
        </div>
      </div>

      <p className="flex gap-2 rounded-xl border border-emerald-700/40 bg-emerald-950/50 px-4 py-3 text-xs leading-5 text-emerald-200/90">
        <Info size={15} className="mt-0.5 shrink-0" />
        <span>La stima usa la media settimanale × 52 ÷ 12. Il quindicinale conta metà; gli interventi a spot non sono ricorrenti e restano fuori dalla stima. Un prezzo mensile concordato sostituisce la stima: il riepilogo non è una fattura.{spotOnly > 0 ? ` ${spotOnly === 1 ? "1 cliente ha" : `${spotOnly} clienti hanno`} solo interventi a spot.` : ""}</span>
      </p>

      <div className="space-y-2">
        {clients.length ? clients.map((client) => {
          const items = getInterventions(client);
          const onlySpot = items.length > 0 && items.every((item) => recurrenceOf(item) === "spot");
          return <button type="button" key={client.uuid} onClick={() => onSelectClient(client)} className="flex w-full flex-wrap items-center justify-between gap-3 rounded-2xl border border-emerald-800/30 bg-[#f4f9f2] px-4 py-4 text-left shadow-sm transition hover:bg-white active:scale-[.99] sm:px-5">
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <strong className="text-base font-extrabold text-emerald-950">{client.name}</strong>
                <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${client.isActive ? "bg-emerald-100 text-emerald-800" : "bg-slate-200 text-slate-700"}`}>{client.isActive ? "Attivo" : "Disattivato"}</span>
                {onlySpot && <span className="rounded-full bg-sky-100 px-2 py-0.5 text-[10px] font-bold text-sky-800">solo spot</span>}
              </div>
              <p className="mt-1 flex items-center gap-1.5 text-xs text-emerald-800"><CalendarDays size={13} /> {scheduleLabel(client)}{items.length ? ` · media ${formatMoney(weeklyEquivalent(client))}/settimana` : ""}</p>
            </div>
            <div className="text-right">
              <span className="block text-[10px] font-bold uppercase tracking-wider text-emerald-700/70">{client.monthlyPriceOverride != null ? "Concordato" : items.length ? "Stima mensile" : "Da pianificare"}</span>
              <strong className="text-xl font-black text-emerald-950">{formatMoney(monthlyAmount(client))}</strong>
            </div>
            <ChevronRight className="h-5 w-5 text-emerald-600" />
          </button>;
        }) : <div className="rounded-2xl border border-dashed border-emerald-700 bg-emerald-950/40 p-8 text-center text-sm text-emerald-300"><CircleDollarSign className="mx-auto mb-2 h-6 w-6" />Nessun cliente da mostrare.</div>}
      </div>
    </div>
  </div>;
}

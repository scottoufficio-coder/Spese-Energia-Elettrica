"use client";

import { useRef, useState } from "react";
import { ArrowLeft, Clipboard, Download, FileJson, FileSpreadsheet, FolderOpen, ShieldCheck, Upload, X } from "lucide-react";
import type { ClientData, ServiceData } from "@/types/client";
import { formatDayMonth, getInterventions, localDate, monthlyAmount, monthlyEstimate, recurrenceOf, weeklyEquivalent } from "@/lib/client-utils";
import { parseBackup, type BackupData } from "@/lib/backup";
import { OfflineStorageManager, type RestoreResult } from "@/lib/offline-manager";

type Props = {
  clients: ClientData[];
  services: ServiceData[];
  isOpen: boolean;
  storageReady: boolean;
  onClose: () => void;
  onRestore: (backup: BackupData, replaceExisting: boolean) => Promise<RestoreResult>;
};
type PreparedFile = { content: string; filename: string; mime: string; count: number; servicesCount: number; pending: number; kind: "json" | "csv" };
type Screen = "home" | "ready" | "restore";
const optionClass = "flex w-full items-center gap-3 rounded-2xl border border-emerald-600/40 bg-emerald-900/40 p-4 text-left hover:bg-emerald-900/80 disabled:opacity-50";
const primaryClass = "inline-flex min-h-12 items-center justify-center gap-2 rounded-xl bg-emerald-400 px-4 py-3 text-sm font-extrabold text-emerald-950 hover:bg-emerald-300 disabled:opacity-50";

function csvFor(clients: ClientData[]): string {
  const headers = ["Nome", "Partita IVA", "Stato", "Prezzo base", "Interventi pianificati", "Media settimanale", "Stima mensile", "Prezzo mensile indicato", "Tipo mensile", "Servizio", "Indirizzo", "Telefono", "Email", "Data attivazione", "Data disattivazione", "Note"];
  const cell = (value: unknown) => { let valueText = String(value ?? ""); if (/^[\t\r\n ]*[=+@-]/.test(valueText)) valueText = "'" + valueText; return `"${valueText.replace(/"/g, '""')}"`; };
  const describe = (item: ReturnType<typeof getInterventions>[number], base: number) => {
    const recurrence = recurrenceOf(item);
    const when = recurrence === "spot" ? `Spot ${formatDayMonth(item.spotDate)}` : recurrence === "biweekly" ? `${item.day} quindicinale (rif. ${formatDayMonth(item.anchorDate)})` : `${item.day} settimanale`;
    return `${when}: ${item.time || "orario da concordare"}, ${item.durationHours == null ? "durata non indicata" : `${item.durationHours} ore`}, €${Number(item.price ?? base).toFixed(2)}`;
  };
  const rows = clients.map((client) => [client.name, client.vatNumber || "", client.isActive ? "Attivo" : "Disattivato", Number(client.currentPrice).toFixed(2), getInterventions(client).map((item) => describe(item, Number(client.currentPrice))).join(" | "), weeklyEquivalent(client).toFixed(2), monthlyEstimate(client).toFixed(2), monthlyAmount(client).toFixed(2), client.monthlyPriceOverride == null ? "Stima" : "Concordato", client.category || "", client.address || "", client.phone || "", client.email || "", client.activationDate || "", client.deactivationDate || "", client.notes || ""].map(cell).join(";"));
  return "\uFEFF" + [headers.map(cell).join(";"), ...rows].join("\n");
}

function isAppleStandalone(): boolean {
  const standalone = window.matchMedia?.("(display-mode: standalone)").matches || (navigator as Navigator & { standalone?: boolean }).standalone === true;
  const apple = /iPad|iPhone|iPod/i.test(navigator.userAgent) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
  return Boolean(standalone && apple);
}

function BackupPanel({ clients, services, storageReady, onClose, onRestore }: Omit<Props, "isOpen">) {
  const [screen, setScreen] = useState<Screen>("home");
  const [prepared, setPrepared] = useState<PreparedFile | null>(null);
  const [backup, setBackup] = useState<BackupData | null>(null);
  const [status, setStatus] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [showText, setShowText] = useState(false);
  const [confirmReplace, setConfirmReplace] = useState(false);
  const fileInput = useRef<HTMLInputElement>(null);

  async function prepare(kind: "json" | "csv") {
    setBusy(true); setError(""); setStatus("");
    try {
      const snapshot = await OfflineStorageManager.getBackupSnapshot();
      const savedClients = snapshot.clients, savedServices = snapshot.services;
      const filename = `${kind === "json" ? "backup_schede_clienti" : "schede_clienti"}_${localDate()}.${kind}`;
      const content = kind === "json" ? JSON.stringify({ format: "schede-clienti-backup-v2", exportedAt: new Date().toISOString(), clients: savedClients, services: savedServices }, null, 2) : csvFor(savedClients);
      setPrepared({ content, filename, mime: kind === "json" ? "application/json" : "text/csv", count: savedClients.length, servicesCount: savedServices.length, pending: snapshot.pending, kind });
      setShowText(false); setScreen("ready");
    } catch (reason) {
      console.error("Backup preparation failed", reason);
      setError("Non riesco a leggere i dati sull’iPad. Controlla lo spazio disponibile e riprova.");
    } finally { setBusy(false); }
  }

  function downloadFile(file: File) {
    try {
      const url = URL.createObjectURL(file);
      const link = document.createElement("a"); link.href = url; link.download = file.name; link.rel = "noopener";
      document.body.appendChild(link); link.click(); link.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 60000);
      setStatus("Scaricamento avviato. Controlla nell’app File, nella cartella Download.");
    } catch {
      setError("Scaricamento non disponibile. Usa l’alternativa per copiare il testo qui sotto.");
      setShowText(true);
    }
  }

  function savePrepared() {
    if (!prepared || busy) return;
    setError(""); setStatus("");
    try {
      const original = new File([prepared.content], prepared.filename, { type: prepared.mime });
      const plain = new File([prepared.content], prepared.filename, { type: "text/plain" });
      const canShare = (file: File) => {
        try { return typeof navigator.share === "function" && typeof navigator.canShare === "function" && navigator.canShare({ files: [file] }); }
        catch { return false; }
      };
      const file = canShare(original) ? original : canShare(plain) ? plain : null;
      if (file) {
        setBusy(true);
        // La chiamata avviene direttamente dal tocco: iPadOS richiede un gesto recente.
        navigator.share({ files: [file] }).then(() => {
          setStatus("Se hai scelto ‘Salva su File’, apri l’app File per verificare la copia.");
        }).catch((reason) => {
          if (reason && typeof reason === "object" && "name" in reason && reason.name === "AbortError") setStatus("Salvataggio annullato: tocca di nuovo ‘Salva su File’ per riprovare.");
          else { setError("Non riesco ad aprire il menu di condivisione. Prova l’alternativa qui sotto."); setShowText(true); }
        }).finally(() => setBusy(false));
      } else if (!isAppleStandalone()) {
        downloadFile(original);
      } else {
        setError("Su questa versione dell’iPad il menu per salvare il file non è disponibile. Usa l’alternativa qui sotto o apri la versione aggiornata in Safari dopo aver sincronizzato.");
        setShowText(true);
      }
    } catch (reason) {
      console.warn("Backup sharing failed", reason);
      setError("Non riesco a preparare il salvataggio. Usa l’alternativa qui sotto."); setShowText(true);
    }
  }

  async function copyText() {
    if (!prepared) return;
    try {
      if (!navigator.clipboard?.writeText) throw new Error("Clipboard unavailable");
      await navigator.clipboard.writeText(prepared.content);
      setStatus("Testo copiato. Puoi incollarlo in una nota privata come copia alternativa.");
    } catch { setError("Tieni premuto nel riquadro, scegli ‘Seleziona tutto’ e poi ‘Copia’."); }
  }

  async function chooseFile(file: File | undefined) {
    setError(""); setStatus(""); setBackup(null); setConfirmReplace(false);
    if (!file) return;
    if (file.size > 50 * 1024 * 1024) { setError("Il file supera 50 MB: dividilo o richiedi assistenza per il ripristino."); return; }
    setBusy(true);
    try {
      const content = typeof file.text === "function" ? await file.text() : await new Promise<string>((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(String(reader.result)); reader.onerror = () => reject(reader.error); reader.readAsText(file); });
      setBackup(parseBackup(JSON.parse(content.replace(/^\uFEFF/, ""))));
      setStatus("File verificato. Scegli come ripristinare le schede.");
    } catch (reason) {
      setError(reason instanceof SyntaxError ? "Il file non contiene JSON valido. Nessun dato è stato modificato." : `${reason instanceof Error ? reason.message : "Il file non è valido."} Nessun dato è stato modificato.`);
    } finally { setBusy(false); }
  }

  async function restore(replaceExisting: boolean) {
    if (!backup) return;
    setBusy(true); setError(""); setStatus("");
    try {
      const result = await onRestore(backup, replaceExisting);
      setStatus(`Ripristino salvato su iPad: ${result.clientsAdded} schede aggiunte, ${result.clientsReplaced} sostituite, ${result.clientsSkipped} mantenute. Servizi aggiunti: ${result.servicesAdded}.`);
      setBackup(null); setConfirmReplace(false);
    } catch (reason) {
      console.error("Backup restore failed", reason);
      setError("Ripristino non riuscito. Nessuna modifica è stata salvata: controlla lo spazio disponibile.");
    } finally { setBusy(false); }
  }

  const clientIds = new Set(clients.map((item) => item.uuid));
  const serviceIds = new Set(services.map((item) => item.uuid));
  const serviceNames = new Set(services.map((item) => item.name.trim().toLocaleLowerCase("it")));
  const clientDuplicates = backup?.clients.filter((item) => clientIds.has(item.uuid)).length || 0;
  const serviceDuplicates = backup?.services.filter((item) => serviceIds.has(item.uuid) || serviceNames.has(item.name.trim().toLocaleLowerCase("it"))).length || 0;
  const goHome = () => { setScreen("home"); setPrepared(null); setBackup(null); setStatus(""); setError(""); setShowText(false); setConfirmReplace(false); };

  return <div data-rolodex-modal="true" className="fixed inset-0 z-50 flex items-center justify-center bg-emerald-950/80 p-4 text-emerald-100 backdrop-blur-sm">
    <div role="dialog" aria-modal="true" aria-labelledby="backup-title" className="flex max-h-[90dvh] w-full max-w-xl flex-col overflow-hidden rounded-3xl border border-emerald-500/40 bg-emerald-950 shadow-2xl">
      <div className="flex shrink-0 items-center justify-between border-b border-emerald-800 bg-emerald-900/60 px-5 py-4"><div><h2 id="backup-title" className="flex items-center gap-2 text-lg font-extrabold text-white"><ShieldCheck size={20} className="text-emerald-400" /> Backup e ripristino</h2><p className="mt-1 text-xs text-emerald-300">Una copia delle schede da conservare nell’app File</p></div><button type="button" aria-label="Chiudi backup" onClick={onClose} className="rounded-full p-2 text-emerald-300 hover:bg-emerald-800"><X size={20} /></button></div>
      <div className="touch-scroll flex-1 space-y-4 overflow-y-auto p-5 sm:p-6">
        {!storageReady && <p role="alert" className="rounded-xl bg-red-950 p-3 text-sm text-red-200">La memoria dell’iPad non è disponibile: il backup non può essere preparato.</p>}
        {screen === "home" && <>
          <p className="text-sm leading-6 text-emerald-200/85">Il backup completo comprende clienti, partita IVA, prezzi, interventi, storico e servizi. Puoi prepararlo anche senza internet.</p>
          <button type="button" onClick={() => void prepare("json")} disabled={!storageReady || busy} className={optionClass}><span className="rounded-xl bg-emerald-500/20 p-2.5 text-emerald-300"><FileJson size={23} /></span><span className="flex-1"><strong className="block text-sm text-white">{busy ? "Preparazione…" : "Prepara backup completo"}</strong><span className="text-xs text-emerald-300">Per salvare e ripristinare le schede</span></span></button>
          <button type="button" onClick={() => void prepare("csv")} disabled={!storageReady || busy} className={optionClass}><span className="rounded-xl bg-emerald-500/20 p-2.5 text-emerald-300"><FileSpreadsheet size={23} /></span><span className="flex-1"><strong className="block text-sm text-white">Esporta CSV</strong><span className="text-xs text-emerald-300">Per aprire i dati in un foglio di calcolo</span></span></button>
          <button type="button" onClick={() => { setScreen("restore"); setError(""); setStatus(""); }} disabled={!storageReady || busy} className={optionClass}><span className="rounded-xl bg-emerald-500/20 p-2.5 text-emerald-300"><Upload size={23} /></span><span className="flex-1"><strong className="block text-sm text-white">Ripristina da un backup</strong><span className="text-xs text-emerald-300">Scegli un file JSON salvato in precedenza</span></span></button>
        </>}
        {screen === "ready" && prepared && <>
          <button type="button" onClick={goHome} className="inline-flex items-center gap-1 text-sm font-semibold text-emerald-300"><ArrowLeft size={16} /> Indietro</button>
          <div className="rounded-2xl border border-emerald-600/40 bg-emerald-900/40 p-4"><h3 className="font-bold text-white">{prepared.kind === "json" ? "Backup pronto" : "CSV pronto"}</h3><p className="mt-1 text-sm text-emerald-200">{prepared.count} schede{prepared.kind === "json" ? ` e ${prepared.servicesCount} servizi` : ""} · {prepared.filename}</p>{prepared.pending > 0 && <p className="mt-2 text-xs leading-5 text-amber-200">Sono incluse anche {prepared.pending} modifiche ancora in attesa di sincronizzazione.</p>}</div>
          <p className="text-sm leading-6 text-emerald-200/90">Tocca <strong>Salva su File</strong>. Nel menu dell’iPad scegli <strong>Salva su File</strong>, seleziona una cartella e tocca <strong>Salva</strong>.</p>
          <button type="button" onClick={savePrepared} disabled={busy} className={`${primaryClass} w-full`}><FolderOpen size={18} /> {busy ? "Apertura…" : "Salva su File"}</button>
          <button type="button" onClick={() => setShowText((value) => !value)} className="text-xs font-semibold text-emerald-300 underline underline-offset-4">{showText ? "Nascondi alternativa" : "Il menu non si apre? Mostra alternativa"}</button>
          {showText && <div className="space-y-3 rounded-2xl border border-emerald-700/50 bg-emerald-900/30 p-4"><p className="text-xs leading-5 text-emerald-200">Puoi copiare il testo e conservarlo in una nota privata come copia alternativa. Contiene dati personali: non condividerlo con altre persone.</p><textarea readOnly aria-label="Contenuto della copia di backup" value={prepared.content} rows={5} className="w-full rounded-xl border border-emerald-700 bg-emerald-950 p-3 font-mono text-xs text-emerald-100" /><button type="button" onClick={() => void copyText()} className="inline-flex min-h-10 items-center gap-2 rounded-xl border border-emerald-600 px-3 py-2 text-xs font-bold text-emerald-100"><Clipboard size={15} /> Copia testo</button></div>}
        </>}
        {screen === "restore" && <>
          <button type="button" onClick={goHome} className="inline-flex items-center gap-1 text-sm font-semibold text-emerald-300"><ArrowLeft size={16} /> Indietro</button>
          <p className="text-sm leading-6 text-emerald-200/85">Scegli un backup JSON dall’app File. Per sicurezza, puoi aggiungere solo le schede mancanti oppure confermare esplicitamente la sostituzione di quelle con lo stesso identificativo.</p>
          <input ref={fileInput} type="file" accept=".json,application/json,text/plain" className="sr-only" aria-label="Seleziona file di backup JSON" onChange={(e) => { const file = e.currentTarget.files?.[0]; e.currentTarget.value = ""; void chooseFile(file); }} />
          <button type="button" onClick={() => fileInput.current?.click()} disabled={busy} className={`${primaryClass} w-full`}><FolderOpen size={18} /> Scegli backup da File</button>
          {backup && <div className="space-y-3 rounded-2xl border border-emerald-600/40 bg-emerald-900/40 p-4"><p className="text-sm text-white"><strong>{backup.clients.length} schede</strong> e <strong>{backup.services.length} servizi</strong> nel file. Su questo iPad risultano già presenti {clientDuplicates} schede e {serviceDuplicates} servizi.</p><button type="button" onClick={() => void restore(false)} disabled={busy} className={`${primaryClass} w-full`}>Aggiungi solo i mancanti</button>{!confirmReplace ? <button type="button" onClick={() => setConfirmReplace(true)} disabled={busy} className="w-full rounded-xl border border-amber-500/50 px-4 py-3 text-sm font-bold text-amber-200">Sostituisci anche quelli esistenti…</button> : <div className="space-y-2 rounded-xl border border-amber-500/40 bg-amber-950/60 p-3"><p className="text-xs leading-5 text-amber-100">Attenzione: le schede e i servizi con lo stesso identificativo saranno sostituiti su questo iPad e, alla sincronizzazione, anche sul server. Le altre schede non vengono eliminate.</p><div className="flex flex-wrap gap-2"><button type="button" onClick={() => void restore(true)} disabled={busy} className="rounded-lg bg-amber-500 px-3 py-2 text-xs font-extrabold text-amber-950">Conferma sostituzione</button><button type="button" onClick={() => setConfirmReplace(false)} className="px-3 py-2 text-xs text-amber-100">Annulla</button></div></div>}</div>}
          <p className="text-xs leading-5 text-emerald-300/70">Il ripristino non elimina le schede assenti dal backup. Se una scheda è già presente sul server, la modalità “solo i mancanti” la mantiene senza sovrascriverla.</p>
        </>}
        {status && <p role="status" className="rounded-xl border border-emerald-600/40 bg-emerald-900/50 p-3 text-sm text-emerald-100">{status}</p>}
        {error && <p role="alert" className="rounded-xl border border-red-500/40 bg-red-950/70 p-3 text-sm text-red-200">{error}</p>}
      </div>
      <div className="flex shrink-0 justify-end border-t border-emerald-800 px-5 py-4"><button type="button" onClick={onClose} className="rounded-xl border border-emerald-700 px-4 py-2 text-sm font-semibold text-emerald-200">Chiudi</button></div>
    </div>
  </div>;
}

export function ExportModal(props: Props) {
  return props.isOpen ? <BackupPanel {...props} /> : null;
}

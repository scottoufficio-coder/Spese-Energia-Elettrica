"use client";

import { useMemo, useState } from "react";
import { CalendarDays, ChevronLeft, ChevronRight, Clock3, Eye, EyeOff, MapPin, Repeat2, Sparkles } from "lucide-react";
import type { ClientData, Recurrence, WeeklyIntervention } from "@/types/client";
import { WEEK_DAYS } from "@/types/client";
import { addDays, formatDayMonth, formatMoney, formatWeekRange, getInterventions, isoDate, occursOn, recurrenceOf, round2, startOfWeek, timeToMinutes, weekdayName } from "@/lib/client-utils";

type Entry = { client: ClientData; intervention: WeeklyIntervention | null; date: string | null; scheduled: boolean; recurrence: Recurrence | "none" };
type Props = { clients: ClientData[]; onSelectClient: (client: ClientData) => void };

const recurrenceBadge: Record<Recurrence, { label: string; className: string }> = {
  weekly: { label: "settimanale", className: "bg-emerald-600/15 text-emerald-800" },
  biweekly: { label: "2 sett.", className: "bg-amber-500/20 text-amber-800" },
  spot: { label: "spot", className: "bg-sky-500/15 text-sky-800" },
};

function priceOf(entry: Entry) {
  return Number(entry.intervention?.price ?? entry.client.currentPrice ?? 0);
}

export function WeeklyScheduleView({ clients, onSelectClient }: Props) {
  const [offset, setOffset] = useState(0);
  const [showAll, setShowAll] = useState(false);

  const monday = useMemo(() => isoDate(addDays(startOfWeek(new Date()), offset * 7)), [offset]);
  const dates = useMemo(() => Array.from({ length: 7 }, (_, index) => isoDate(addDays(new Date(`${monday}T00:00:00.000Z`), index))), [monday]);

  const grouped = useMemo(() => {
    const map = new Map<string, Entry[]>();
    for (const date of dates) map.set(date, []);
    const unresolved: Entry[] = [];

    for (const client of clients) {
      const interventions = getInterventions(client);
      if (!interventions.length) {
        unresolved.push({ client, intervention: null, date: null, scheduled: true, recurrence: "none" });
        continue;
      }
      for (const date of dates) {
        const dayName = weekdayName(date);
        for (const intervention of interventions) {
          const recurrence = recurrenceOf(intervention);
          const spotDate = intervention.spotDate || null;
          if (recurrence === "spot") {
            if (spotDate === date) map.get(date)?.push({ client, intervention, date, scheduled: true, recurrence });
            else if (showAll && spotDate && weekdayName(spotDate) === dayName) map.get(date)?.push({ client, intervention, date: spotDate, scheduled: false, recurrence });
            continue;
          }
          if (intervention.day !== dayName) continue;
          const scheduled = occursOn(intervention, date);
          if (scheduled || showAll) map.get(date)?.push({ client, intervention, date, scheduled, recurrence });
        }
      }
    }

    for (const list of map.values()) {
      list.sort((a, b) => timeToMinutes(a.intervention?.time) - timeToMinutes(b.intervention?.time) || a.client.name.localeCompare(b.client.name, "it", { sensitivity: "base" }));
    }
    unresolved.sort((a, b) => a.client.name.localeCompare(b.client.name, "it", { sensitivity: "base" }));
    return { map, unresolved };
  }, [clients, dates, showAll]);

  const scheduledThisWeek = dates.reduce((total, date) => total + (grouped.map.get(date) || []).filter((entry) => entry.scheduled).length, 0);
  const expectedTotal = round2(dates.reduce((total, date) => total + (grouped.map.get(date) || []).filter((entry) => entry.scheduled && entry.client.isActive).reduce((sum, entry) => sum + priceOf(entry), 0), 0));

  return <div className="flex flex-1 flex-col overflow-hidden p-4 sm:p-6">
    <div className="mb-4 flex flex-wrap items-center justify-between gap-3 border-b border-emerald-800/40 pb-4">
      <div className="flex items-center gap-2">
        <CalendarDays className="h-5 w-5 text-emerald-400" />
        <div><h2 className="font-bold text-emerald-50">Agenda settimanale</h2><p className="text-xs text-emerald-300">Settimanali, quindicinali e spot · ordinati per orario</p></div>
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex items-center gap-1 rounded-xl border border-emerald-700/50 bg-emerald-900/60 p-1">
          <button type="button" aria-label="Settimana precedente" onClick={() => setOffset((value) => value - 1)} className="rounded-lg p-2 text-emerald-100 hover:bg-emerald-800"><ChevronLeft size={18} /></button>
          <button type="button" onClick={() => setOffset(0)} className="min-h-9 rounded-lg px-3 text-xs font-bold text-emerald-100 hover:bg-emerald-800">{offset === 0 ? "Questa settimana" : "Torna a oggi"}</button>
          <button type="button" aria-label="Settimana successiva" onClick={() => setOffset((value) => value + 1)} className="rounded-lg p-2 text-emerald-100 hover:bg-emerald-800"><ChevronRight size={18} /></button>
        </div>
        <div className="rounded-xl border border-emerald-700/50 bg-emerald-900/50 px-4 py-2">
          <span className="block text-[10px] font-bold uppercase tracking-wide text-emerald-300">{formatWeekRange(monday)}</span>
          <strong className="text-sm text-white">{scheduledThisWeek} interventi · {formatMoney(expectedTotal)}</strong>
        </div>
      </div>
    </div>

    <div className="mb-3 flex flex-wrap items-center gap-2">
      <span className="rounded-full bg-emerald-600/15 px-2.5 py-1 text-[11px] font-bold text-emerald-200">settimanale</span>
      <span className="rounded-full bg-amber-500/20 px-2.5 py-1 text-[11px] font-bold text-amber-200">2 sett. = quindicinale</span>
      <span className="rounded-full bg-sky-500/20 px-2.5 py-1 text-[11px] font-bold text-sky-200">spot = una tantum</span>
      <button type="button" onClick={() => setShowAll((value) => !value)} className="ml-auto inline-flex min-h-9 items-center gap-2 rounded-xl border border-emerald-700/50 bg-emerald-900/60 px-3 py-1.5 text-xs font-bold text-emerald-100 hover:bg-emerald-800">
        {showAll ? <EyeOff size={15} /> : <Eye size={15} />}{showAll ? "Nascondi non previsti" : "Mostra anche i non previsti"}
      </button>
    </div>

    <div className="touch-scroll flex-1 overflow-x-auto pb-6">
      <div className="flex h-full min-w-max gap-3">
        {WEEK_DAYS.map((day, index) => {
          const date = dates[index];
          const entries = grouped.map.get(date) || [];
          const active = entries.filter((entry) => entry.scheduled);
          const dayTotal = round2(active.filter((entry) => entry.client.isActive).reduce((sum, entry) => sum + priceOf(entry), 0));
          const isToday = date === isoDate(new Date());
          return <section key={date} className={`flex w-64 flex-col overflow-hidden rounded-2xl border bg-emerald-950/70 ${isToday ? "border-emerald-400/70" : "border-emerald-700/40"}`}>
            <div className="border-b border-emerald-700/50 bg-emerald-900 px-4 py-3">
              <div className="flex items-center justify-between">
                <div><h3 className="font-bold text-white">{day}</h3><span className="text-xs text-emerald-300">{formatDayMonth(date)} · {active.length} {active.length === 1 ? "intervento" : "interventi"}</span></div>
                {active.length > 0 && <span className="rounded-lg bg-emerald-800 px-2 py-1 text-xs font-bold text-emerald-100">{formatMoney(dayTotal)}</span>}
              </div>
            </div>
            <div className="touch-scroll flex-1 space-y-2 overflow-y-auto p-3">
              {entries.length === 0 ? <p className="p-4 text-center text-xs text-emerald-400/60">Nessun intervento</p> : entries.map((entry, position) => {
                const badge = entry.recurrence === "none" ? null : recurrenceBadge[entry.recurrence];
                return <button type="button" key={`${entry.client.uuid}-${position}`} onClick={() => onSelectClient(entry.client)} className={`card-embossed-sheet w-full rounded-xl border p-3 text-left ${entry.scheduled ? "border-emerald-900/20" : "border-dashed border-emerald-500/40 opacity-60"} ${!entry.client.isActive ? "opacity-65" : ""}`}>
                  <div className="flex items-start justify-between gap-2">
                    <strong className="text-sm text-emerald-950">{entry.client.name}</strong>
                    <span className="shrink-0 text-sm font-black text-emerald-900">{formatMoney(priceOf(entry))}</span>
                  </div>
                  <div className="mt-1 flex flex-wrap items-center gap-1.5">
                    {entry.intervention?.time ? <span className="inline-flex items-center gap-1 rounded-md bg-emerald-950/10 px-1.5 py-0.5 text-[11px] font-bold text-emerald-900"><Clock3 size={12} /> {entry.intervention.time}</span> : <span className="text-[11px] text-emerald-800/70">orario da concordare</span>}
                    {badge && <span className={`rounded-md px-1.5 py-0.5 text-[10px] font-bold ${badge.className}`}>{badge.label}</span>}
                    {!entry.scheduled && <span className="rounded-md bg-slate-200 px-1.5 py-0.5 text-[10px] font-bold text-slate-700">non in questa settimana</span>}
                  </div>
                  {entry.recurrence === "spot" && entry.date && <p className="mt-1 text-[11px] text-emerald-800/80">Data spot: {formatDayMonth(entry.date)}</p>}
                  {entry.intervention?.durationHours != null && <p className="mt-1 flex items-center gap-1 text-[11px] text-emerald-800"><Repeat2 size={12} /> durata {String(entry.intervention.durationHours).replace(".", ",")} ore</p>}
                  {entry.client.address && <p className="mt-1 flex items-center gap-1 text-[11px] text-emerald-800/80"><MapPin size={12} /> <span className="truncate">{entry.client.address}</span></p>}
                  {!entry.client.isActive && <span className="mt-2 inline-block text-[10px] font-bold text-red-700">Disattivato</span>}
                </button>;
              })}
            </div>
          </section>;
        })}

        {grouped.unresolved.length > 0 && <section className="flex w-64 flex-col overflow-hidden rounded-2xl border border-dashed border-emerald-600/50 bg-emerald-950/50">
          <div className="border-b border-emerald-700/50 bg-emerald-900 px-4 py-3"><h3 className="font-bold text-white">Da concordare</h3><span className="text-xs text-emerald-300">{grouped.unresolved.length} {grouped.unresolved.length === 1 ? "scheda" : "schede"}</span></div>
          <div className="touch-scroll flex-1 space-y-2 overflow-y-auto p-3">
            {grouped.unresolved.map((entry) => <button type="button" key={entry.client.uuid} onClick={() => onSelectClient(entry.client)} className="card-embossed-sheet w-full rounded-xl border border-emerald-900/20 p-3 text-left"><strong className="text-sm text-emerald-950">{entry.client.name}</strong><p className="mt-1 flex items-center gap-1 text-[11px] text-emerald-800/80"><Sparkles size={12} /> Nessun giorno impostato</p></button>)}
          </div>
        </section>}
      </div>
    </div>
  </div>;
}



export interface PriceHistoryItem {
  id: string;
  date: string;
  oldPrice: number;
  newPrice: number;
  reason: string;
  createdAt: string;
}

export type Recurrence = "weekly" | "biweekly" | "spot";

/** Un intervento ricorrente o a spot. prezzo null = prezzo base del cliente. */
export interface WeeklyIntervention {
  day: string;
  time: string;
  price: number | null;
  durationHours: number | null;
  /** Assente nelle schede precedenti: equivale a "weekly". */
  recurrence?: Recurrence;
  /** Quindicinale: una data in cui l'intervento è previsto, usata per alternare le settimane. */
  anchorDate?: string | null;
  /** A spot: la data del singolo intervento. */
  spotDate?: string | null;
}

export interface ServiceData {
  uuid: string;
  name: string;
  isDeleted?: boolean;
  _syncStatus?: "synced" | "pending_create" | "pending_update" | "pending_delete";
}

export interface ClientData {
  id?: number;
  uuid: string;
  name: string;
  vatNumber?: string;
  phone?: string;
  email?: string;
  address?: string;
  currentPrice: number;
  priceHistory: PriceHistoryItem[];
  activationDate: string;
  deactivationDate?: string | null;
  isActive: boolean;
  /** Vecchi campi mantenuti per non perdere schede esistenti. */
  interventionDay: string;
  interventionTime?: string;
  interventions?: WeeklyIntervention[] | null;
  monthlyPriceOverride?: number | null;
  notes?: string;
  category?: string;
  isDeleted?: boolean;
  createdAt?: string;
  updatedAt?: string;
  _syncStatus?: "synced" | "pending_create" | "pending_update" | "pending_delete";
  _lastLocalEdit?: number;
}

export type InterventionDayOption = "Lunedì" | "Martedì" | "Mercoledì" | "Giovedì" | "Venerdì" | "Sabato" | "Domenica" | "Da concordare";

export const INTERVENTION_DAYS: InterventionDayOption[] = ["Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì", "Sabato", "Domenica", "Da concordare"];
export const WEEK_DAYS = INTERVENTION_DAYS.slice(0, 7) as Exclude<InterventionDayOption, "Da concordare">[];

export const RECURRENCE_LABELS: Record<Recurrence, string> = {
  weekly: "Ogni settimana",
  biweekly: "Ogni 2 settimane",
  spot: "A spot (una volta)",
};

export const CATEGORIES = [
  "Manutenzione Giardino & Verde",
  "Pulizie & Sanificazione",
  "Assistenza Tecnica & Impianti",
  "Piscine & Spa",
  "Disinfestazione & Trattamenti",
  "Consulenza Periodica",
  "Altro Servizio",
];

export const DEFAULT_SERVICES: ServiceData[] = CATEGORIES.map((name, index) => ({ uuid: `service-default-${index + 1}`, name }));

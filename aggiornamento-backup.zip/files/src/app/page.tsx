"use client";

import React, { useState, useEffect, useMemo, useCallback, useRef } from "react";
import { HeaderNav, ViewMode } from "@/components/HeaderNav";
import { Roller3D } from "@/components/Roller3D";
import { GridView } from "@/components/GridView";
import { WeeklyScheduleView } from "@/components/WeeklyScheduleView";
import { MonthlyView } from "@/components/MonthlyView";
import { ClientSheetModal } from "@/components/ClientSheetModal";
import { NewClientModal } from "@/components/NewClientModal";
import { ServiceCatalogModal } from "@/components/ServiceCatalogModal";
import { ExportModal } from "@/components/ExportModal";
import { GitHubAndIpadGuideModal } from "@/components/GitHubAndIpadGuideModal";
import { AccessGate } from "@/components/AccessGate";
import type { ClientData, ServiceData } from "@/types/client";
import type { BackupData } from "@/lib/backup";
import { getInterventions } from "@/lib/client-utils";
import { OfflineStorageManager } from "@/lib/offline-manager";

type AuthState = "checking" | "open" | "required" | "misconfigured";

export default function ClientsAppPage() {
  const [clients, setClients] = useState<ClientData[]>([]);
  const [services, setServices] = useState<ServiceData[]>([]);
  const [loading, setLoading] = useState(true);
  const [storageReady, setStorageReady] = useState(false);
  const [storageError, setStorageError] = useState("");
  const [viewMode, setViewMode] = useState<ViewMode>("roller");
  const [selectedClient, setSelectedClient] = useState<ClientData | null>(null);
  const [isNewClientModalOpen, setIsNewClientModalOpen] = useState(false);
  const [isServicesOpen, setIsServicesOpen] = useState(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [isGuideModalOpen, setIsGuideModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterStatus, setFilterStatus] = useState<"all" | "active" | "inactive">("all");
  const [filterDay, setFilterDay] = useState("all");
  const [isOnline, setIsOnline] = useState(true);
  const [isSimulatedOffline, setIsSimulatedOffline] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [pendingCount, setPendingCount] = useState(0);
  const [offlineReady, setOfflineReady] = useState(false);
  const [syncedOnce, setSyncedOnce] = useState(false);
  const [serverError, setServerError] = useState(false);
  const [demoMode, setDemoMode] = useState(false);
  const [authState, setAuthState] = useState<AuthState>("checking");
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [notification, setNotification] = useState<string | null>(null);
  const syncRunning = useRef(false), syncAgain = useRef(false), mutationVersion = useRef(0);

  const showNotification = useCallback((msg: string) => {
    setNotification(msg);
    window.setTimeout(() => setNotification((current) => current === msg ? null : current), 4500);
  }, []);

  useEffect(() => {
    let active = true;
    if ("serviceWorker" in navigator && window.isSecureContext) {
      (async () => {
        const registration = await navigator.serviceWorker.register("/sw.js", { updateViaCache: "none" });
        const worker = registration.installing || registration.waiting || registration.active;
        if (worker && worker.state !== "activated") {
          await new Promise<void>((resolve, reject) => {
            const check = () => {
              if (worker.state === "activated") { worker.removeEventListener("statechange", check); resolve(); }
              else if (worker.state === "redundant") { worker.removeEventListener("statechange", check); reject(new Error("Service worker non installato")); }
            };
            worker.addEventListener("statechange", check); check();
          });
        }
        await navigator.serviceWorker.ready;
        if (!(await caches.has("schede-clienti-shell-v8"))) throw new Error("Cache offline non disponibile");
        const cache = await caches.open("schede-clienti-shell-v8");
        const keys = await cache.keys();
        if (!(await cache.match("/")) || !keys.some((item) => new URL(item.url).pathname.startsWith("/_next/static/"))) throw new Error("Download dei file offline incompleto");
        if (active) setOfflineReady(true);
      })().catch((error) => console.warn("Preparazione offline non riuscita:", error));
    }
    return () => { active = false; };
  }, []);

  useEffect(() => {
    let active = true;
    const online = () => setIsOnline(true), offline = () => setIsOnline(false);
    setIsOnline(navigator.onLine);
    window.addEventListener("online", online); window.addEventListener("offline", offline);
    (async () => {
      try {
        await OfflineStorageManager.initialize();
        const [localClients, localServices, pending, servicePending] = await Promise.all([
          OfflineStorageManager.getLocalClients(), OfflineStorageManager.getLocalServices(),
          OfflineStorageManager.getPendingMutations(), OfflineStorageManager.getPendingServiceMutations(),
        ]);
        if (active) { setClients(localClients); setServices(localServices); setPendingCount(pending.length + servicePending.length); setStorageReady(true); }
        navigator.storage?.persist?.().catch(() => {});
      } catch (error) {
        console.error("Archivio offline non disponibile:", error);
        if (active) setStorageError("Memoria dell’iPad non disponibile: controlla lo spazio e disattiva la navigazione privata. Nessuna modifica può essere salvata.");
      } finally { if (active) setLoading(false); }
    })();
    return () => { active = false; window.removeEventListener("online", online); window.removeEventListener("offline", offline); };
  }, []);

  useEffect(() => {
    let active = true;
    if (!isOnline) { setAuthState("open"); return; }
    fetch("/api/auth", { cache: "no-store" }).then((response) => {
      if (!response.ok) throw new Error("Server non disponibile"); return response.json();
    }).then((data) => {
      if (!active) return;
      setDemoMode(data.mode === "demo");
      setAuthState(data.mode === "misconfigured" ? "misconfigured" : data.authenticated ? "open" : "required");
    }).catch(() => { if (active) { setServerError(true); setAuthState("open"); } });
    return () => { active = false; };
  }, [isOnline]);

  const syncWithServer = useCallback(async (manual = false) => {
    if (!storageReady || !isOnline || isSimulatedOffline || authState !== "open") return;
    if (syncRunning.current) { syncAgain.current = true; return; }
    syncRunning.current = true; setIsSyncing(true);
    let synchronizedChanges = false;
    let restoreConflicts = 0;
    try {
      do {
        syncAgain.current = false;
        const [mutations, serviceMutations] = await Promise.all([OfflineStorageManager.getPendingMutations(), OfflineStorageManager.getPendingServiceMutations()]);
        const hasChanges = mutations.length > 0 || serviceMutations.length > 0;
        const response = await fetch(hasChanges ? "/api/clients/sync" : "/api/clients", hasChanges ? { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ mutations, serviceMutations }) } : { cache: "no-store" });
        if (response.status === 401) { setAuthState("required"); return; }
        if (!response.ok) throw new Error(`Server ${response.status}`);
        const data = await response.json();
        if (!Array.isArray(data.clients) || !Array.isArray(data.services)) throw new Error("Risposta del server non valida");
        if (Array.isArray(data.restoreConflicts)) restoreConflicts += data.restoreConflicts.length;
        const version = mutationVersion.current;
        const merged = await OfflineStorageManager.applyServerSnapshot(data.clients, mutations, data.services, serviceMutations);
        const [remaining, serviceRemaining] = await Promise.all([OfflineStorageManager.getPendingMutations(), OfflineStorageManager.getPendingServiceMutations()]);
        if (version === mutationVersion.current) { setClients(merged.clients); setServices(merged.services); }
        setPendingCount(remaining.length + serviceRemaining.length); setServerError(false); setSyncedOnce(true);
        if (hasChanges) synchronizedChanges = true;
        if (remaining.length || serviceRemaining.length) syncAgain.current = true;
      } while (syncAgain.current && navigator.onLine);
      if (restoreConflicts > 0) showNotification("Alcune voci erano già presenti online e sono state mantenute senza sostituirle.");
      else if (manual || synchronizedChanges) showNotification("Schede e servizi sincronizzati con il server.");
    } catch (error) {
      console.warn("Sincronizzazione non riuscita:", error); setServerError(true);
      if (manual) showNotification("Sincronizzazione non riuscita: le modifiche restano sull’iPad.");
    } finally {
      syncRunning.current = false; setIsSyncing(false);
      try { const [a, b] = await Promise.all([OfflineStorageManager.getPendingMutations(), OfflineStorageManager.getPendingServiceMutations()]); setPendingCount(a.length + b.length); } catch { /* avviso già visibile */ }
    }
  }, [authState, isOnline, isSimulatedOffline, showNotification, storageReady]);

  useEffect(() => { if (storageReady && isOnline && !isSimulatedOffline && authState === "open") void syncWithServer(); }, [storageReady, isOnline, isSimulatedOffline, authState, syncWithServer]);

  const saveLocally = useCallback(async (type: "create" | "update" | "delete", client: ClientData): Promise<boolean> => {
    if (!storageReady) { showNotification("Memoria locale non disponibile: la scheda non è stata salvata."); return false; }
    const version = ++mutationVersion.current;
    try {
      await OfflineStorageManager.recordMutation(type, client);
      const [localClients, pending, servicePending] = await Promise.all([OfflineStorageManager.getLocalClients(), OfflineStorageManager.getPendingMutations(), OfflineStorageManager.getPendingServiceMutations()]);
      if (version === mutationVersion.current) setClients(localClients);
      setPendingCount(pending.length + servicePending.length);
      showNotification(isOnline && !isSimulatedOffline ? "Salvato su iPad. Sincronizzazione in corso…" : "Salvato su iPad. Sarà sincronizzato al ritorno online.");
      void syncWithServer(); return true;
    } catch (error) { console.error(error); showNotification("Salvataggio non riuscito. Controlla lo spazio sull’iPad."); return false; }
  }, [storageReady, isOnline, isSimulatedOffline, showNotification, syncWithServer]);

  const saveService = useCallback(async (type: "create" | "delete", service: ServiceData): Promise<boolean> => {
    if (!storageReady) { showNotification("Memoria locale non disponibile."); return false; }
    const version = ++mutationVersion.current;
    try {
      await OfflineStorageManager.recordServiceMutation(type, service);
      const [localServices, pending, servicePending] = await Promise.all([OfflineStorageManager.getLocalServices(), OfflineStorageManager.getPendingMutations(), OfflineStorageManager.getPendingServiceMutations()]);
      if (version === mutationVersion.current) setServices(localServices);
      setPendingCount(pending.length + servicePending.length);
      showNotification(isOnline && !isSimulatedOffline ? "Servizi salvati su iPad. Sincronizzazione in corso…" : "Servizi salvati su iPad e in attesa di sincronizzazione.");
      void syncWithServer(); return true;
    } catch (error) { console.error(error); showNotification("Impossibile salvare il servizio su iPad."); return false; }
  }, [storageReady, isOnline, isSimulatedOffline, showNotification, syncWithServer]);

  const restoreLocally = useCallback(async (backup: BackupData, replaceExisting: boolean) => {
    if (!storageReady) throw new Error("Memoria locale non disponibile.");
    const version = ++mutationVersion.current;
    const result = await OfflineStorageManager.restoreBackup(backup, replaceExisting);
    try {
      const [localClients, localServices, pending, servicePending] = await Promise.all([
        OfflineStorageManager.getLocalClients(), OfflineStorageManager.getLocalServices(),
        OfflineStorageManager.getPendingMutations(), OfflineStorageManager.getPendingServiceMutations(),
      ]);
      if (version === mutationVersion.current) { setClients(localClients); setServices(localServices); }
      setPendingCount(pending.length + servicePending.length);
    } catch (error) {
      console.warn("Ripristino salvato ma vista non aggiornata", error);
      showNotification("Ripristino salvato. Riapri l’app per aggiornare la vista.");
    }
    if (result.clientsAdded + result.clientsReplaced + result.servicesAdded + result.servicesReplaced > 0) {
      showNotification(isOnline && !isSimulatedOffline ? "Ripristino salvato su iPad. Sincronizzazione in corso…" : "Ripristino salvato su iPad; si sincronizzerà quando torni online.");
      void syncWithServer();
    }
    return result;
  }, [storageReady, isOnline, isSimulatedOffline, showNotification, syncWithServer]);

  const handleCreateClient = (client: ClientData) => saveLocally("create", client);
  const handleUpdateClient = (client: ClientData) => saveLocally("update", client);
  const handleDeleteClient = (uuid: string) => { const target = clients.find((client) => client.uuid === uuid); return target ? saveLocally("delete", { ...target, isDeleted: true }) : Promise.resolve(false); };

  const filteredClients = useMemo(() => {
    const query = searchQuery.trim().toLocaleLowerCase("it");
    return clients.filter((client) => {
      if (query && ![client.name, client.vatNumber, client.address, client.notes, client.category].some((value) => (value || "").toLocaleLowerCase("it").includes(query))) return false;
      if (filterStatus === "active" && !client.isActive) return false;
      if (filterStatus === "inactive" && client.isActive) return false;
      const schedule = getInterventions(client);
      if (filterDay === "Da concordare" && schedule.length) return false;
      if (filterDay !== "all" && filterDay !== "Da concordare" && !schedule.some((item) => item.day === filterDay)) return false;
      return true;
    }).sort((a, b) => a.name.localeCompare(b.name, "it", { sensitivity: "base" }));
  }, [clients, searchQuery, filterStatus, filterDay]);

  return <div className="flex h-[100dvh] flex-col overflow-hidden bg-gradient-to-b from-[#043324] via-[#064e3b] to-[#022218] font-sans text-emerald-100">
    {notification && <div role="status" className="fixed right-4 top-16 z-[90] rounded-2xl bg-emerald-400 p-3 text-xs font-bold text-emerald-950 shadow-2xl">✓ {notification}</div>}
    <HeaderNav viewMode={viewMode} onViewChange={setViewMode} searchQuery={searchQuery} onSearchChange={setSearchQuery} filterStatus={filterStatus} onFilterStatusChange={setFilterStatus} filterDay={filterDay} onFilterDayChange={setFilterDay} onAddNewClient={() => setIsNewClientModalOpen(true)} onManageServices={() => setIsServicesOpen(true)} onExportData={() => setIsExportModalOpen(true)} onOpenGuide={() => setIsGuideModalOpen(true)} isOnline={isOnline} isSimulatedOffline={isSimulatedOffline} pendingCount={pendingCount} isSyncing={isSyncing} onSync={() => void syncWithServer(true)} onToggleSimulatedOffline={() => setIsSimulatedOffline((value) => !value)} totalClients={clients.length} />
    {storageError && <div role="alert" className="shrink-0 bg-red-950 px-4 py-2 text-center text-xs font-semibold text-red-200">{storageError}</div>}
    {!storageError && serverError && isOnline && !isSimulatedOffline && <div role="status" className="shrink-0 bg-amber-950 px-4 py-2 text-center text-xs font-semibold text-amber-200">Server non raggiungibile: le modifiche restano su questo iPad e saranno sincronizzate quando possibile.</div>}
    {!storageError && !serverError && demoMode && <div className="shrink-0 bg-amber-950/80 px-4 py-1.5 text-center text-[11px] font-semibold text-amber-200">Anteprima dimostrativa: non inserire dati personali reali. Per l’uso definitivo serve una pubblicazione protetta.</div>}
    {!storageError && !serverError && isOnline && !isSimulatedOffline && (!offlineReady || !storageReady || !syncedOnce || isSyncing || pendingCount > 0) && <div className="shrink-0 bg-emerald-950/80 px-4 py-1.5 text-center text-[11px] text-emerald-200">Preparazione offline in corso: lascia l’app aperta e connessa.</div>}
    {offlineReady && storageReady && !storageError && !serverError && ((!isOnline || isSimulatedOffline) || (syncedOnce && !isSyncing && pendingCount === 0 && authState === "open")) && <div className="shrink-0 bg-emerald-950/50 px-4 py-1 text-center text-[11px] text-emerald-300">✓ App pronta per l’uso offline su questo dispositivo</div>}
    <main className="relative flex flex-1 flex-col overflow-hidden">{loading ? <div className="flex flex-1 items-center justify-center text-sm text-emerald-300">Preparazione dello schedario…</div> : viewMode === "roller" ? <Roller3D clients={filteredClients} onSelectClient={setSelectedClient} soundEnabled={soundEnabled} onToggleSound={() => setSoundEnabled((value) => !value)} /> : viewMode === "grid" ? <GridView clients={filteredClients} onSelectClient={setSelectedClient} /> : viewMode === "monthly" ? <MonthlyView clients={filteredClients} onSelectClient={setSelectedClient} /> : <WeeklyScheduleView clients={filteredClients} onSelectClient={setSelectedClient} />}</main>
    <ClientSheetModal client={selectedClient} isOpen={Boolean(selectedClient)} services={services} onManageServices={() => setIsServicesOpen(true)} onClose={() => setSelectedClient(null)} onSave={handleUpdateClient} onDelete={handleDeleteClient} />
    <NewClientModal isOpen={isNewClientModalOpen} services={services} onManageServices={() => setIsServicesOpen(true)} onClose={() => setIsNewClientModalOpen(false)} onCreate={handleCreateClient} />
    <ServiceCatalogModal isOpen={isServicesOpen} services={services} onClose={() => setIsServicesOpen(false)} onCreate={(service) => saveService("create", service)} onDelete={(service) => saveService("delete", service)} />
    <ExportModal clients={clients} services={services} isOpen={isExportModalOpen} storageReady={storageReady} onRestore={restoreLocally} onClose={() => setIsExportModalOpen(false)} />
    <GitHubAndIpadGuideModal isOpen={isGuideModalOpen} onClose={() => setIsGuideModalOpen(false)} />
    {(authState === "required" || authState === "misconfigured") && <AccessGate mode={authState} onAuthenticated={() => setAuthState("open")} />}
  </div>;
}

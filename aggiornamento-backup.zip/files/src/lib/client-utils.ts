import { ClientData, Recurrence, WeeklyIntervention, WEEK_DAYS } from "@/types/client";

const DAY_MS = 86400000;

export function recurrenceOf(item: WeeklyIntervention): Recurrence {
  return item.recurrence === "biweekly" || item.recurrence === "spot" ? item.recurrence : "weekly";
}

export function getInterventions(client: ClientData): WeeklyIntervention[] {
  if (Array.isArray(client.interventions)) return client.interventions;
  if (!client.interventionDay || client.interventionDay === "Da concordare") return [];
  return [{ day: client.interventionDay, time: client.interventionTime || "", price: null, durationHours: null, recurrence: "weekly" }];
}

export function parseISODate(value?: string | null): Date | null {
  if (!value) return null;
  const match = /^(\d{4})-(\d{2})-(\d{2})/.exec(value.trim());
  if (!match) return null;
  const date = new Date(Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3])));
  return Number.isNaN(date.getTime()) ? null : date;
}

export function isoDate(value: Date): string {
  return value.toISOString().slice(0, 10);
}

export function addDays(value: Date, days: number): Date {
  const next = new Date(value.getTime());
  next.setUTCDate(next.getUTCDate() + days);
  return next;
}

/** Lunedì della settimana della data indicata (orario UTC, solo giorno). */
export function startOfWeek(value: Date): Date {
  const date = new Date(Date.UTC(value.getUTCFullYear(), value.getUTCMonth(), value.getUTCDate()));
  const offset = (date.getUTCDay() + 6) % 7;
  return addDays(date, -offset);
}

export function weekDates(mondayISO: string): string[] {
  const start = parseISODate(mondayISO) ?? startOfWeek(new Date());
  return Array.from({ length: 7 }, (_, index) => isoDate(addDays(start, index)));
}

export function weekdayName(iso?: string | null): string {
  const date = parseISODate(iso);
  if (!date) return "Da concordare";
  return WEEK_DAYS[(date.getUTCDay() + 6) % 7] ?? "Da concordare";
}

export function formatDayMonth(iso?: string | null): string {
  const date = parseISODate(iso);
  if (!date) return "";
  return new Intl.DateTimeFormat("it-IT", { day: "2-digit", month: "short", timeZone: "UTC" }).format(date);
}

export function formatWeekRange(mondayISO: string): string {
  const start = parseISODate(mondayISO);
  if (!start) return "";
  const end = addDays(start, 6);
  const sameMonth = start.getUTCMonth() === end.getUTCMonth();
  const first = new Intl.DateTimeFormat("it-IT", { day: "numeric", ...(sameMonth ? {} : { month: "short" }), timeZone: "UTC" }).format(start);
  const second = new Intl.DateTimeFormat("it-IT", { day: "numeric", month: "short", year: "numeric", timeZone: "UTC" }).format(end);
  return `${first} – ${second}`;
}

/** Minuti dalla mezzanotte per ordinare gli interventi; orari assenti finiscono in fondo. */
export function timeToMinutes(value?: string | null): number {
  if (!value) return Number.POSITIVE_INFINITY;
  const clock = /(\d{1,2})[:.](\d{2})/.exec(value);
  if (clock) return Number(clock[1]) * 60 + Number(clock[2]);
  const hours = /(\d{1,2})\s*(?:h|ore)/i.exec(value);
  if (hours) return Number(hours[1]) * 60;
  return Number.POSITIVE_INFINITY - 1;
}

/** L'intervento cade nel giorno indicato? Gestisce settimanale, quindicinale e spot. */
export function occursOn(item: WeeklyIntervention, iso: string): boolean {
  const recurrence = recurrenceOf(item);
  if (recurrence === "spot") return Boolean(item.spotDate) && item.spotDate === iso;
  if (weekdayName(iso) !== item.day) return false;
  if (recurrence === "weekly") return true;
  const anchor = parseISODate(item.anchorDate);
  const target = parseISODate(iso);
  if (!anchor || !target) return true;
  const weeks = Math.round((startOfWeek(target).getTime() - startOfWeek(anchor).getTime()) / (7 * DAY_MS));
  return Math.abs(weeks) % 2 === 0;
}

export interface AgendaEntry {
  client: ClientData;
  intervention: WeeklyIntervention;
  date: string;
  scheduled: boolean;
}

/** Interventi del cliente che compaiono nella settimana, ordinati per giorno e ora. */
export function weekOccurrences(client: ClientData, mondayISO: string): AgendaEntry[] {
  const entries: AgendaEntry[] = [];
  for (const date of weekDates(mondayISO)) {
    for (const intervention of getInterventions(client)) {
      if (occursOn(intervention, date)) entries.push({ client, intervention, date, scheduled: true });
    }
  }
  return entries.sort((a, b) => a.date.localeCompare(b.date) || timeToMinutes(a.intervention.time) - timeToMinutes(b.intervention.time));
}

/** Entrate settimanali medie: il quindicinale conta metà, lo spot non entra nella stima. */
export function weeklyEquivalent(client: ClientData): number {
  return getInterventions(client).reduce((total, item) => {
    const recurrence = recurrenceOf(item);
    if (recurrence === "spot") return total;
    const amount = Number(item.price ?? client.currentPrice ?? 0);
    return total + (recurrence === "biweekly" ? amount / 2 : amount);
  }, 0);
}

export function round2(value: number): number {
  return Math.round((value + Number.EPSILON) * 100) / 100;
}

/** Stima mensile: media settimanale × 52 ÷ 12. */
export function monthlyEstimate(client: ClientData): number {
  return round2((weeklyEquivalent(client) * 52) / 12);
}

export function monthlyAmount(client: ClientData): number {
  return client.monthlyPriceOverride != null ? Number(client.monthlyPriceOverride) : monthlyEstimate(client);
}

export function formatMoney(value: number): string {
  return new Intl.NumberFormat("it-IT", { style: "currency", currency: "EUR" }).format(Number(value) || 0);
}

export function scheduleLabel(client: ClientData): string {
  const labels = getInterventions(client).map((item) => {
    const recurrence = recurrenceOf(item);
    if (recurrence === "spot") return `Spot ${formatDayMonth(item.spotDate)}`.trim();
    return recurrence === "biweekly" ? `${item.day} (2 sett.)` : item.day;
  });
  return labels.length ? labels.join(", ") : "Da concordare";
}

export function validSchedule(items: unknown): items is WeeklyIntervention[] {
  if (!Array.isArray(items) || items.length > 40) return false;
  const seen = new Set<string>();
  for (const item of items) {
    if (!item || typeof item.day !== "string") return false;
    const recurrence = recurrenceOf(item as WeeklyIntervention);
    if (recurrence !== "spot" && !WEEK_DAYS.includes(item.day as typeof WEEK_DAYS[number])) return false;
    if (typeof item.time !== "string" || item.time.length > 100) return false;
    if (item.price !== null && (!Number.isFinite(item.price) || item.price < 0 || item.price > 99999999.99)) return false;
    if (item.durationHours !== null && (!Number.isFinite(item.durationHours) || item.durationHours <= 0 || item.durationHours > 24)) return false;
    const anchor = item.anchorDate ?? null;
    const spot = item.spotDate ?? null;
    if (anchor !== null && (typeof anchor !== "string" || !parseISODate(anchor))) return false;
    if (spot !== null && (typeof spot !== "string" || !parseISODate(spot))) return false;
    if (recurrence === "spot" && !spot) return false;
    const key = recurrence === "spot" ? `spot-${spot}` : `rec-${item.day}`;
    if (seen.has(key)) return false;
    seen.add(key);
  }
  return true;
}

/** Chiave usata per confrontare due versioni della stessa pianificazione. */
export function interventionKey(item: WeeklyIntervention): string {
  return recurrenceOf(item) === "spot" ? `spot-${item.spotDate ?? ""}` : `rec-${item.day}`;
}

export function interventionLabel(item: WeeklyIntervention): string {
  const recurrence = recurrenceOf(item);
  if (recurrence === "spot") return `Spot ${formatDayMonth(item.spotDate)}`;
  return recurrence === "biweekly" ? `${item.day} (quindicinale)` : item.day;
}

export function localDate(): string {
  const date = new Date();
  const tz = date.getTimezoneOffset() * 60000;
  return new Date(date.getTime() - tz).toISOString().slice(0, 10);
}

# Schede Clienti per iPad

Schedario per clienti con rullo, ricerca, agenda, variazioni di prezzo, note e funzionamento offline. È una **web app installabile (PWA)**, non un'app dell'App Store.

## Prima di iniziare

Per la guida semplificata da iPad, apri la pagina `/pubblicazione` dell'anteprima: mostra un passaggio alla volta e non richiede di inserire password nella guida.

- L'anteprima del progetto è temporanea e **non è destinata ai dati reali**. L'ambiente locale non è automaticamente collegato al tuo account GitHub.
- Per un utilizzo duraturo servono: un repository GitHub, un database PostgreSQL, un servizio di hosting HTTPS e una password dell'app. Verifica prezzi, quote e termini dei servizi scelti.
- Le schede precaricate sono **esempi**, non clienti reali. Eliminandole, non vengono ricreate.
- Anche con una password d'accesso, i dati offline risiedono sul dispositivo: proteggi l'iPad con un codice di sblocco e fai backup. Per esigenze aziendali o dati particolarmente sensibili è necessaria un'ulteriore valutazione di sicurezza.

## 1. Pubblicare il codice su GitHub

### Metodo solo iPad, senza terminale

1. Apri la guida `/ipad` nell'anteprima, scarica l'archivio ZIP e lascialo così com'è: non serve estrarlo.
2. Accedi a <https://github.com/new>, scegli `schede-clienti-ipad`, seleziona **Private** e crea un repository nuovo.
3. Nel repository vuoto, seleziona **uploading an existing file**, oppure **Add file → Upload files**. Con **choose your files** seleziona lo ZIP dall'app File e premi **Commit changes**.
4. Nella guida `/ipad`, copia il nome del file e il testo dell'automazione con gli appositi pulsanti. Su GitHub usa **Add file → Create new file**, incolla il nome e il testo e conferma **Commit changes** sul ramo principale.
5. In GitHub tocca **Actions** e aspetta il segno verde. L'automazione estrae lo ZIP e salva i file. Torna su **Code** e verifica che `package.json`, `src`, `public` e `db` siano nella pagina principale.

L'automazione usa il `GITHUB_TOKEN` temporaneo fornito da GitHub con permesso di scrittura sui contenuti del solo repository; non serve creare o condividere token personali. Si ferma se trova già un progetto per non sovrascriverlo. Puoi rimuovere il workflow dal repository dopo il successo. GitHub Actions ha quote di utilizzo e potrebbe essere disattivato da impostazioni dell'account o dell'organizzazione.

L'archivio contiene solo il codice del progetto: non contiene `.env`, credenziali, `node_modules` o i dati salvati nel database dell'anteprima. Un repository GitHub conserva il codice: per utilizzare l'app serve anche pubblicarla su un hosting HTTPS con il suo database, come spiegato sotto.

### Metodo con Git da terminale

1. Crea un repository **privato** su <https://github.com/new>, senza aggiungere README o .gitignore.
2. Ottieni i file del progetto dall'ambiente in cui sono stati creati oppure apri il suo terminale. Se hai estratto lo ZIP su un computer, inizializza prima Git nella cartella con `git init` (lo ZIP non contiene la cronologia Git). Nella cartella del progetto, esegui questi comandi, sostituendo indirizzo e nome utente con quelli reali:

```bash
git add .
git commit -m "Aggiornamento app schede clienti"
git branch -M main
git remote add origin https://github.com/TUO-USERNAME/schede-clienti-ipad.git
git push -u origin main
```

Se il repository remoto è già collegato, non eseguire nuovamente `git remote add origin`. GitHub può richiedere l'autenticazione tramite browser o token. `.env` e le credenziali sono esclusi da Git: **non pubblicarli**.

## 2. Creare e inizializzare PostgreSQL

1. Crea un database PostgreSQL presso un provider, ad esempio <https://neon.com/>.
2. Apri **SQL Editor** del database appena creato. Dalla pagina `/guida` dell'app puoi premere **Copia configurazione** e incollare il risultato nell'editor. In alternativa, apri `db/setup.sql` nel repository GitHub, copia tutto il suo contenuto nell'editor SQL e avvialo una sola volta. Il file crea la tabella richiesta senza eliminare le tabelle esistenti.
3. Dopo aver eseguito lo script, usa **Connect** e copia la stringa di connessione PostgreSQL completa (preferibilmente pooled). Incollala subito nel campo `DATABASE_URL` di Vercel descritto sotto. È una credenziale segreta: non inserirla nel repository.
4. In alternativa, chi usa un terminale può impostare `DATABASE_URL_UNPOOLED` (oppure `DATABASE_URL`) e usare `npx drizzle-kit push`.

## 3. Pubblicare l'app HTTPS con Vercel

1. Accedi a <https://vercel.com/> e importa il repository GitHub con **Add New Project**. Vercel riconosce Next.js.
2. Prima del deploy, in **Environment Variables**, aggiungi:
   - `DATABASE_URL`: la stringa PostgreSQL del database creato al punto 2;
   - `APP_PASSWORD`: una password lunga almeno 12 caratteri scelta da te. Serve per accedere allo schedario online; non è il codice dell'iPad.
3. Avvia **Deploy**. Se modifichi una variabile in seguito, effettua un nuovo deploy affinché abbia effetto.
4. Apri l'URL HTTPS di produzione fornito da Vercel. Accedi con `APP_PASSWORD`. Il primo caricamento può inserire schede dimostrative in un database nuovo.

Negli ambienti di produzione normali, senza una `APP_PASSWORD` valida, le API dei clienti restano bloccate. I sandbox temporanei E2B possono avviare automaticamente la modalità dimostrativa; `ALLOW_DEMO_MODE=true` è un'opzione solo per anteprime usa-e-getta. Non inserire dati reali in una demo. La password è un accesso condiviso, non un sistema multiutente; il semplice limite tentativi per istanza va integrato con protezioni adeguate all'uso previsto.

## 4. Aggiungere l'app su iPad

1. Con l'iPad collegato a Internet, apri **Safari** e visita l'indirizzo HTTPS di produzione.
2. Tocca **Condividi** (quadrato con freccia verso l'alto), quindi **Aggiungi a schermata Home**. Se non appare, scorri il menu o tocca Altro.
3. Se disponibile, attiva **Apri come app web**, poi tocca **Aggiungi**.
4. Apri la nuova icona dalla Home mentre sei ancora online. Accedi di nuovo se richiesto: Safari e la web app sulla Home possono avere archivi e sessioni separati.
5. Attendi la scritta **“App pronta per l'uso offline su questo dispositivo”** e attendi che la sincronizzazione termini prima di chiudere la connessione.

Fonte: <https://support.apple.com/guide/ipad/open-as-web-app-ipad8f1f7a29/ipados>.

## 5. Testare e usare l'offline

1. Dopo la preparazione online, attiva **modalità aereo**, chiudi e riapri l'app dall'icona.
2. Crea o modifica una **scheda di prova** e verifica che compaia tra quelle in attesa.
3. Disattiva la modalità aereo, riapri l'app e premi **Sincronizza**. Verifica che il conteggio delle modifiche in attesa torni a zero e che la scheda sia presente anche dopo la riapertura.

Le modifiche vengono salvate in IndexedDB e inviate quando l'app è aperta e la connessione è disponibile. Uno spazio insufficiente, l'eliminazione dell'app/dati del browser o un guasto del dispositivo possono causare la perdita dei dati locali non sincronizzati. Lo spazio non è illimitato.

Per un backup su iPad: apri **Backup → Prepara backup completo → Salva su File**. Nel menu di condivisione scegli **Salva su File**, seleziona una cartella e conferma **Salva**; verifica poi nell'app File. Il backup include anche le modifiche locali non ancora sincronizzate. Se il menu non è disponibile, la schermata offre una copia testuale alternativa. Su browser compatibili con il download il file viene scaricato nella cartella Download.

Puoi usare **Backup → Ripristina da un backup** per scegliere un JSON corrente o precedente. La scelta predefinita aggiunge solo le schede mancanti e non sostituisce quelle già presenti, anche sul server; la sostituzione richiede una conferma esplicita. Il ripristino non elimina le schede non presenti nel file. Conserva le copie in un luogo privato e verificane periodicamente il contenuto.

In caso di modifiche contemporanee della stessa scheda su dispositivi diversi, può prevalere l'ultima sincronizzazione: sincronizza un dispositivo prima di passare all'altro. Non conservare codici o dati sensibili nelle note senza un'adeguata valutazione di sicurezza.

## Ricorrenze degli interventi (settimanale, quindicinale, spot)

Ogni intervento di una scheda ha una ricorrenza:

- **Ogni settimana** — compare in agenda ogni settimana nello stesso giorno.
- **Ogni 2 settimane (quindicinale)** — richiede una *settimana di riferimento*: da quella data l'agenda alterna una settimana sì e una no. La media settimanale conta metà importo.
- **A spot** — richiede la *data dell'intervento* e compare solo nella settimana di quella data. Non entra nella stima mensile.

L'agenda resta settimanale (lunedì–domenica) con frecce per la settimana precedente/successiva, il pulsante "Torna a oggi" e l'opzione "Mostra anche i non previsti" che mostra in grigio tratteggiato ciò che non cade in quella settimana. In ogni giorno i clienti sono **ordinati per orario**; chi non ha orario va in fondo e le schede senza giorni finiscono nella colonna "Da concordare".

Le ricorrenze sono salvate dentro il campo JSON `interventions`: **non serve alcuna modifica al database** per questo aggiornamento.

## Nuove funzioni clienti e aggiornamento dati

La scheda supporta partita IVA, prezzo base modificabile, più giorni settimanali con prezzo e durata per ciascuno, prezzo mensile concordato oppure stima automatica (totale settimanale × 52 ÷ 12) e servizi personalizzati sincronizzati anche offline. Le schede precedenti restano compatibili.

Per aggiornare una pubblicazione esistente, eseguire prima `db/upgrade-clienti-v2.sql` sul database PostgreSQL dopo un backup. La migrazione è additiva e ripetibile. La guida `/aggiornamento-clienti` accompagna l’utente iPad. Il pacchetto speciale va preparato con l'opzione `--migration clienti-v2` e richiede la versione aggiornata del workflow copiabile da `public/aggiorna-github.txt`; il workflow NON esegue la migrazione del database.

## Aggiornare l'app da iPad

Se il repository GitHub è collegato a Vercel, le modifiche approvate nel ramo di produzione generano normalmente una nuova pubblicazione, senza ricreare database, password o icona. La guida `/aggiornamenti` mostra come configurare una volta il workflow copiabile da `public/aggiorna-github.txt`. L'utente carica poi il pacchetto `aggiornamento-ipad.zip`, attende il risultato in **Actions**, apre la proposta dal riepilogo e la approva con **Create pull request → Merge pull request**. Controllare in Vercel che la nuova versione di produzione sia **Ready** prima di riaprire l'app online.

Per chi prepara il pacchetto: dopo aver committato le modifiche, eseguire `python3 scripts/create_ipad_update.py BASE HEAD`, dove BASE è esattamente la versione dei file già presenti nel repository dell'utente. Il pacchetto include solo i file cambiati e le impronte delle versioni precedenti. Il workflow controlla tutte le impronte prima di apportare modifiche e crea un ramo separato; la pubblicazione richiede l'approvazione dell'utente. Non modifica il database. Le modifiche a `src/db/` o `db/` sono escluse dagli aggiornamenti ordinari e richiedono una procedura e migrazione separata; per la sola migrazione documentata `clienti-v2` è previsto il flag esplicito. Sincronizzare i dati ed esportare un backup prima di aggiornare.

## Sviluppo locale

Il progetto usa Next.js, Drizzle e PostgreSQL. Configura `DATABASE_URL` in `.env`, prepara la tabella con `npx drizzle-kit push`, quindi esegui `npm run dev`. Una password `APP_PASSWORD` abilita l'accesso anche in sviluppo. Per una demo locale senza dati reali si può impostare `ALLOW_DEMO_MODE=true`; non è una modalità sicura per la produzione.
